"""
Tests for glossary_v2.py — verify schema upgrade + safe enforcement.

Run: python test_glossary_v2.py
"""

import sys
import os

# Make sure we import the local module
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import glossary_v2 as g2


# ============== UPGRADE TESTS ==============

def test_upgrade_legacy_basic():
    """Basic legacy entry → v2 με sensible defaults."""
    legacy = {"source": "London", "target": "Λονδίνο", "note": "place"}
    v2 = g2.upgrade_legacy_entry(legacy)
    assert v2 is not None
    assert v2["source"] == "London"
    assert v2["target"] == "Λονδίνο"
    assert v2["category"] == "place"
    assert v2["lock"] == "strict"
    assert "id" in v2
    assert v2["frequency"] == 0
    assert v2["alternatives_considered"] == []
    print("  ✓ test_upgrade_legacy_basic")


def test_upgrade_legacy_term_default_to_flexible_via_fixed():
    """Legacy 'term' → fixed-expression / strict (per default mapping)."""
    legacy = {"source": "data set", "target": "σύνολο δεδομένων", "note": "term"}
    v2 = g2.upgrade_legacy_entry(legacy)
    assert v2["category"] == "fixed-expression"
    # fixed-expression default = strict
    assert v2["lock"] == "strict"
    print("  ✓ test_upgrade_legacy_term_default")


def test_upgrade_legacy_with_alternatives_in_target():
    """Old entries had 'X/Y' or 'X ή Y' inline → split out into alternatives."""
    legacy = {"source": "monastery", "target": "μοναστήρι ή μονή", "note": "term"}
    v2 = g2.upgrade_legacy_entry(legacy)
    assert v2["target"] == "μοναστήρι"
    assert v2["alternatives_considered"] == ["μονή"]

    legacy2 = {"source": "town", "target": "πόλη/κωμόπολη", "note": "place"}
    v2b = g2.upgrade_legacy_entry(legacy2)
    assert v2b["target"] == "πόλη"
    assert v2b["alternatives_considered"] == ["κωμόπολη"]
    print("  ✓ test_upgrade_legacy_with_alternatives")


def test_upgrade_legacy_unknown_note():
    """Άγνωστο note → fallback fixed-expression."""
    legacy = {"source": "X", "target": "Χ", "note": "something_weird"}
    v2 = g2.upgrade_legacy_entry(legacy)
    assert v2["category"] == "fixed-expression"
    assert v2["lock"] == "strict"
    print("  ✓ test_upgrade_legacy_unknown_note")


def test_upgrade_legacy_no_note():
    """Entry χωρίς note → fixed-expression default."""
    legacy = {"source": "X", "target": "Χ"}
    v2 = g2.upgrade_legacy_entry(legacy)
    assert v2["category"] == "fixed-expression"
    print("  ✓ test_upgrade_legacy_no_note")


def test_upgrade_legacy_invalid():
    """Invalid entries → None."""
    assert g2.upgrade_legacy_entry({}) is None
    assert g2.upgrade_legacy_entry({"source": ""}) is None
    assert g2.upgrade_legacy_entry({"target": "Χ"}) is None
    assert g2.upgrade_legacy_entry("not a dict") is None
    assert g2.upgrade_legacy_entry(None) is None
    print("  ✓ test_upgrade_legacy_invalid")


def test_upgrade_idempotency():
    """Upgrade ενός v2 entry δεν αλλάζει τα κρίσιμα fields."""
    v2_original = {
        "id": "abc123",
        "source": "London",
        "target": "Λονδίνο",
        "category": "place",
        "lock": "strict",
        "frequency": 5,
        "first_occurrence_paragraph": 4,
        "examples_of_use": ["He went to London."],
        "alternatives_considered": [],
        "needs_footnote": False,
        "translator_note": None,
    }
    v2_upgraded = g2.upgrade_legacy_entry(v2_original)
    assert v2_upgraded["id"] == "abc123"
    assert v2_upgraded["category"] == "place"
    assert v2_upgraded["lock"] == "strict"
    assert v2_upgraded["frequency"] == 5
    assert v2_upgraded["examples_of_use"] == ["He went to London."]
    print("  ✓ test_upgrade_idempotency")


def test_upgrade_v2_invalid_category_falls_back():
    """V2 entry με invalid category → fallback fixed-expression."""
    v2_bad = {
        "source": "X",
        "target": "Χ",
        "category": "alien-category",
        "lock": "strict",
    }
    upgraded = g2.upgrade_legacy_entry(v2_bad)
    assert upgraded["category"] == "fixed-expression"
    print("  ✓ test_upgrade_v2_invalid_category")


def test_upgrade_glossary_list_dedup():
    """Duplicates στη λίστα → ένα μόνο κρατιέται."""
    legacy_list = [
        {"source": "London", "target": "Λονδίνο", "note": "place"},
        {"source": "London", "target": "Λονδίνο", "note": "place"},  # dup
        {"source": "London", "target": "λονδίνο", "note": "place"},  # case-dup
        {"source": "Paris", "target": "Παρίσι", "note": "place"},
    ]
    upgraded = g2.upgrade_glossary_list(legacy_list)
    assert len(upgraded) == 2  # μόνο London και Paris
    sources = [e["source"] for e in upgraded]
    assert "London" in sources
    assert "Paris" in sources
    print("  ✓ test_upgrade_glossary_list_dedup")


def test_upgrade_glossary_list_empty():
    """Empty/None inputs → empty output."""
    assert g2.upgrade_glossary_list([]) == []
    assert g2.upgrade_glossary_list(None) == []
    print("  ✓ test_upgrade_glossary_list_empty")


# ============== ENFORCEMENT TESTS ==============

def test_enforce_skips_flexible():
    """Flexible lock → καμία αντικατάσταση."""
    glossary = [{
        "id": "x", "source": "data", "target": "δεδομένα",
        "category": "term-technical", "lock": "flexible",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = ["Τα ΔΕΔΟΜΕΝΑ είναι σημαντικά."]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    # Δεν έγινε αντικατάσταση γιατί lock=flexible
    assert out[0] == texts[0]
    assert stats["replacements_made"] == 0
    assert stats["skipped_locks"]["flexible"] == 1
    print("  ✓ test_enforce_skips_flexible")


def test_enforce_strict_case_normalization():
    """Strict lock → normalize casing της ακριβούς λέξης."""
    glossary = [{
        "id": "x", "source": "London", "target": "Λονδίνο",
        "category": "place", "lock": "strict",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = ["Πήγε στο λονδίνο για τη συνάντηση."]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    assert out[0] == "Πήγε στο Λονδίνο για τη συνάντηση."
    assert stats["replacements_made"] == 1
    print("  ✓ test_enforce_strict_case_normalization")


def test_enforce_does_not_break_inflection():
    """
    Κρίσιμο test: target='Λονδίνο' ΔΕΝ πρέπει να σπάσει το 'Λονδίνου' (γενική).
    Ούτε να μετατρέψει 'λονδίνου' → 'Λονδίνου' (που θα ήταν substring replacement).
    """
    glossary = [{
        "id": "x", "source": "London", "target": "Λονδίνο",
        "category": "place", "lock": "strict",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = [
        "Έφυγε από το Λονδίνου με το πρωινό τρένο.",  # γενική, χαμένος τόνος
        "Από το λονδίνου ξεκίνησε το ταξίδι.",         # lowercase γενική
    ]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    # Καμία αντικατάσταση: ο match 'λονδίνο' είναι μέσα σε 'λονδίνου'
    assert out[0] == texts[0], f"Σπάσαμε τη γενική: {out[0]}"
    assert out[1] == texts[1], f"Σπάσαμε τη γενική: {out[1]}"
    assert stats["replacements_made"] == 0
    assert stats["skipped_inflection_risk"] >= 2
    print("  ✓ test_enforce_does_not_break_inflection")


def test_enforce_alternatives_collapse():
    """LLM γράφει 'Λονδίνο ή Λοντίνο' → ενοποίηση στο canonical."""
    glossary = [{
        "id": "x", "source": "London", "target": "Λονδίνο",
        "category": "place", "lock": "strict",
        "alternatives_considered": ["Λοντίνο"], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = ["Πήγε στο Λονδίνο ή Λοντίνο."]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    assert "ή" not in out[0] or "Λοντίνο" not in out[0]
    assert "Λονδίνο" in out[0]
    assert stats["alternative_collapses"] >= 1
    print("  ✓ test_enforce_alternatives_collapse")


def test_enforce_skips_transliterate():
    """Transliterate lock → skipped, no replacement."""
    glossary = [{
        "id": "x", "source": "Smith", "target": "Σμιθ",
        "category": "person", "lock": "transliterate",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = ["Ο σμιθ έγραψε."]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    # Δεν αλλάζει — lock=transliterate skipped
    assert out[0] == texts[0]
    assert stats["skipped_locks"]["transliterate"] == 1
    print("  ✓ test_enforce_skips_transliterate")


def test_enforce_empty_glossary():
    """Empty glossary → identity."""
    texts = ["κάτι κάτι"]
    out, stats = g2.enforce_glossary_v2(texts, [])
    assert out == texts
    assert stats["replacements_made"] == 0
    print("  ✓ test_enforce_empty_glossary")


def test_enforce_preserves_other_text():
    """Replacement αλλάζει μόνο το target term, όχι ολόκληρη πρόταση."""
    glossary = [{
        "id": "x", "source": "London", "target": "Λονδίνο",
        "category": "place", "lock": "strict",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    texts = ["Στο λονδίνο πάντα βρέχει, αλλά στη Νέα Υόρκη όχι."]
    out, stats = g2.enforce_glossary_v2(texts, glossary)
    assert out[0] == "Στο Λονδίνο πάντα βρέχει, αλλά στη Νέα Υόρκη όχι."
    print("  ✓ test_enforce_preserves_other_text")


# ============== PROMPT FORMATTING TESTS ==============

def test_format_prompt_empty():
    assert g2.format_glossary_for_prompt([]) == ""
    print("  ✓ test_format_prompt_empty")


def test_format_prompt_groups_by_category():
    glossary = [
        {
            "id": "1", "source": "London", "target": "Λονδίνο",
            "category": "place", "lock": "strict",
            "alternatives_considered": [], "frequency": 0,
            "first_occurrence_paragraph": None, "examples_of_use": [],
            "needs_footnote": False, "translator_note": None,
        },
        {
            "id": "2", "source": "John", "target": "Τζον",
            "category": "person", "lock": "strict",
            "alternatives_considered": [], "frequency": 0,
            "first_occurrence_paragraph": None, "examples_of_use": [],
            "needs_footnote": False, "translator_note": None,
        },
        {
            "id": "3", "source": "data set", "target": "σύνολο δεδομένων",
            "category": "term-technical", "lock": "flexible",
            "alternatives_considered": [], "frequency": 0,
            "first_occurrence_paragraph": None, "examples_of_use": [],
            "needs_footnote": False, "translator_note": None,
        },
    ]
    out = g2.format_glossary_for_prompt(glossary)
    assert "[πρόσωπο]" in out
    assert "[τόπος]" in out
    assert "[τεχνικός όρος]" in out
    # Person πριν place; place πριν term-technical (preferred order)
    assert out.index("[πρόσωπο]") < out.index("[τόπος]")
    assert out.index("[τόπος]") < out.index("[τεχνικός όρος]")
    # Lock label εμφανίζεται για flexible
    assert "επιτρέπεται κλίση" in out
    print("  ✓ test_format_prompt_groups_by_category")


def test_format_prompt_do_not_translate():
    glossary = [{
        "id": "1", "source": "ipso facto", "target": "ipso facto",
        "category": "fixed-expression", "lock": "do_not_translate",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": False, "translator_note": None,
    }]
    out = g2.format_glossary_for_prompt(glossary)
    assert "ΔΙΑΤΗΡΗΣΕ ΩΣ ΕΧΕΙ" in out
    print("  ✓ test_format_prompt_do_not_translate")


def test_format_prompt_needs_footnote():
    glossary = [{
        "id": "1", "source": "habeas corpus", "target": "habeas corpus",
        "category": "term-legal", "lock": "do_not_translate",
        "alternatives_considered": [], "frequency": 0,
        "first_occurrence_paragraph": None, "examples_of_use": [],
        "needs_footnote": True, "translator_note": "λατινικός νομικός όρος",
    }]
    out = g2.format_glossary_for_prompt(glossary)
    assert "[χρειάζεται υποσημείωση]" in out
    assert "λατινικός νομικός όρος" in out
    print("  ✓ test_format_prompt_needs_footnote")


# ============== DIAGNOSTICS TESTS ==============

def test_summary():
    glossary = [
        {"category": "person", "lock": "strict", "needs_footnote": False},
        {"category": "place", "lock": "strict", "needs_footnote": False},
        {"category": "term-technical", "lock": "flexible", "needs_footnote": True},
    ]
    s = g2.glossary_summary(glossary)
    assert s["total"] == 3
    assert s["by_category"]["person"] == 1
    assert s["by_lock"]["strict"] == 2
    assert s["by_lock"]["flexible"] == 1
    assert s["needs_footnote"] == 1
    print("  ✓ test_summary")


# ============== INTEGRATION TEST: full pipeline through legacy data ==============

def test_full_legacy_pipeline():
    """
    Simulate ένα πλήρες real-world legacy glossary και verify ότι:
    1. Όλες οι entries αναβαθμίζονται σωστά
    2. Η enforcement δεν χαλάει το κείμενο
    3. Το format_glossary_for_prompt βγάζει readable output
    """
    legacy = [
        {"source": "London", "target": "Λονδίνο", "note": "place"},
        {"source": "John Smith", "target": "Τζον Σμιθ", "note": "person"},
        {"source": "BBC", "target": "BBC", "note": "organization"},
        {"source": "monastery", "target": "μοναστήρι/μονή", "note": "term"},
        {"source": "habeas corpus", "target": "habeas corpus", "note": "legal"},
        {"source": "Hamlet", "target": "Άμλετ", "note": "title"},
        {"source": "", "target": "X"},  # invalid → drop
    ]

    upgraded = g2.upgrade_glossary_list(legacy)
    assert len(upgraded) == 6  # one dropped

    # Check categories distributed σωστά
    cats = {e["source"]: e["category"] for e in upgraded}
    assert cats["London"] == "place"
    assert cats["John Smith"] == "person"
    assert cats["BBC"] == "org"
    assert cats["monastery"] == "fixed-expression"  # term default
    assert cats["habeas corpus"] == "term-legal"
    assert cats["Hamlet"] == "title"

    # monastery legacy "X/Y" split
    monastery_entry = next(e for e in upgraded if e["source"] == "monastery")
    assert monastery_entry["target"] == "μοναστήρι"
    assert monastery_entry["alternatives_considered"] == ["μονή"]

    # Enforcement σε υπαρκτό text
    texts = [
        "Στο λονδίνο γνώρισε τον Τζον Σμιθ.",
        "Πέρασε από το Λονδίνου την περασμένη εβδομάδα.",  # γενική, να μη σπάσει
        "Ο τζον σμιθ είπε ναι.",
    ]
    out, stats = g2.enforce_glossary_v2(texts, upgraded)

    # Λονδίνο normalized σε [0]
    assert "Λονδίνο" in out[0]
    # Λονδίνου παραμένει intact σε [1]
    assert "Λονδίνου" in out[1]

    # Format για prompt
    prompt_block = g2.format_glossary_for_prompt(upgraded)
    assert "Λονδίνο" in prompt_block
    assert "Τζον Σμιθ" in prompt_block
    assert "[πρόσωπο]" in prompt_block
    assert "[τόπος]" in prompt_block
    assert "[νομικός όρος]" in prompt_block
    print("  ✓ test_full_legacy_pipeline")
    print(f"     stats: {stats}")


# ============== RUN ==============

if __name__ == "__main__":
    print("Running glossary_v2 tests...\n")

    print("UPGRADE:")
    test_upgrade_legacy_basic()
    test_upgrade_legacy_term_default_to_flexible_via_fixed()
    test_upgrade_legacy_with_alternatives_in_target()
    test_upgrade_legacy_unknown_note()
    test_upgrade_legacy_no_note()
    test_upgrade_legacy_invalid()
    test_upgrade_idempotency()
    test_upgrade_v2_invalid_category_falls_back()
    test_upgrade_glossary_list_dedup()
    test_upgrade_glossary_list_empty()

    print("\nENFORCEMENT:")
    test_enforce_skips_flexible()
    test_enforce_strict_case_normalization()
    test_enforce_does_not_break_inflection()
    test_enforce_alternatives_collapse()
    test_enforce_skips_transliterate()
    test_enforce_empty_glossary()
    test_enforce_preserves_other_text()

    print("\nFORMATTING:")
    test_format_prompt_empty()
    test_format_prompt_groups_by_category()
    test_format_prompt_do_not_translate()
    test_format_prompt_needs_footnote()

    print("\nDIAGNOSTICS:")
    test_summary()

    print("\nINTEGRATION:")
    test_full_legacy_pipeline()

    print("\n✓ All tests passed.")
