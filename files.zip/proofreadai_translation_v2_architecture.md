# ProofreadAI Translation Engine v2 — Architectural Specification

Σχεδιαστικό έγγραφο για το νέο translation pipeline, χωρίς κώδικα.
Στόχος: εκδοτικό επίπεδο μετάφρασης + αυστηρός ποιοτικός έλεγχος χωρίς ψευδώς θετικά.

---

## 0. Διαγνωστικό του τρέχοντος pipeline

Το υπάρχον σύστημα έχει σωστή σπονδυλική στήλη:

- Prescan σε δύο passes (document analysis + terminology extraction).
- Per-chunk τρία passes (translate → critique → apply fixes), με σύστημα retries.
- Glossary enforcement μέσω post-processing find-replace.
- Quote normalization, mid-word capital fixes, paragraph-count preservation.
- Resume/crash-safe progress saving.
- Στοιχειώδες review queue με flagging βάσει `chunk_review`.

Τέσσερα προβλήματα που πρέπει να λυθούν:

1. **Σύγχυση ρόλων στον critique pass**: ο ίδιος pass προσπαθεί ταυτόχρονα να
   εντοπίσει «πραγματικά λάθη που πρέπει να φτιαχτούν αυτόματα» και «προτάσεις
   προς ανθρώπινο review». Είναι δύο διαφορετικές δουλειές με διαφορετικά
   κριτήρια αυστηρότητας. Το αποτέλεσμα είναι είτε χάνει σοβαρά πράγματα είτε
   επισημαίνει υπερβολικά πολλά κοσμητικά.
2. **Καμία ανίχνευση hard passages πριν τη μετάφραση**: ο critique πιάνει
   ιδίωμα/ειρωνεία/υπαινιγμό αφού έχει ήδη γίνει η κατά λέξη απόδοση. Αυτή η
   λογική προσπαθεί να διορθώσει εκ των υστέρων κάτι που έπρεπε να αποφευχθεί
   από την αρχή.
3. **Glossary χωρίς δομή**: ένα μόνο `note` field ως ελεύθερο κείμενο. Καμία
   διάκριση μεταξύ «πρέπει να γράφεται πάντα έτσι» και «μπορεί να κλιθεί».
   Καμία ένδειξη αν ο όρος *πρέπει να μη μεταφραστεί*.
4. **Καμία global consistency awareness στο audit**: ο per-chunk critique δεν
   μπορεί να δει αν στο chunk 3 αποδίδω «London → Λονδίνο» και στο chunk 17
   «London → Λοντίνο», γιατί δεν έχει γνώση των άλλων chunks.

Η αρχιτεκτονική v2 διορθώνει ακριβώς αυτά τα τέσσερα.

---

## 1. Επισκόπηση και αρχές σχεδίασης

### 1.1. Επτά αρχές

1. **Διαχωρισμός αυτόματης διόρθωσης από human review.** Ό,τι μπορεί να φτιαχτεί
   μηχανικά με ασφάλεια, φτιάχνεται στο pipeline. Ό,τι θέλει κρίση, πάει στο
   audit και στο review UI — ποτέ και τα δύο.
2. **Conservative bias.** Στον audit, default είναι να *μην* προτείνεις αλλαγή.
   Πρόταση μόνο όταν υπάρχει συγκεκριμένο, αναφέρσιμο γλωσσικό πρόβλημα.
3. **Anchored suggestions.** Κάθε πρόταση πρέπει να αναφέρεται σε verbatim
   substring του πρωτοτύπου *και* του target. Χωρίς anchor, δεν περνά.
4. **Validation πριν το UI, όχι μέσα στο prompt.** Ο LLM είναι κακός κριτής
   για το αν μια πρόταση είναι «κενή/κοσμητική» — τα φιλτράρει το server-side
   validation layer με ντετερμινιστικά κριτήρια.
5. **Profile-driven, όχι μία λύση για όλα.** Διαφορετικός system prompt για
   λογοτεχνικό, ακαδημαϊκό, νομικό, θεολογικό, ιστορικό — όχι if/else μέσα στο
   ίδιο prompt.
6. **Global context στον audit, per-chunk processing.** Κάθε audit call βλέπει
   το chunk + document brief + glossary + relevant translation memory snapshot
   + boundary segments.
7. **Structured glossary.** `category` και `lock` διακρίνουν proper nouns από
   common terms, fixed expressions από μεταφραστικές επιλογές.

### 1.2. Διάγραμμα ροής (high-level)

```
┌────────────────────────────────────────────────────────────────────────┐
│                          GENERATION PHASE                              │
├────────────────────────────────────────────────────────────────────────┤
│  1. Prescan v2                                                         │
│     • Pass A: classification + style register + risk flags             │
│     • Pass B: full-text terminology sweep (chunked)                    │
│     • Pass C: risk register (only if any risk flag in Pass A)          │
│     → output: profile, glossary v2, risk register                      │
│                                                                        │
│  2. Per-chunk loop                                                     │
│     for each chunk:                                                    │
│       a. Hard-passage radar (only if chunk has risky markers)          │
│       b. Translate (system prompt = profile-specific, includes radar)  │
│       c. In-pipeline critique (auto-fix only — tightened rules)        │
│       d. Apply fixes (only if issues found)                            │
│       e. Drift sentinel (every N chunks)                               │
│                                                                        │
│  3. Post-processing                                                    │
│     • Glossary enforcement (uses lock=strict only)                     │
│     • Quote normalization                                              │
│     • Mid-word capital fixes                                           │
└────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│                           AUDIT PHASE                                  │
├────────────────────────────────────────────────────────────────────────┤
│  4. Programmatic checks (no LLM, fast, deterministic)                  │
│     • Paragraph count, length ratios, markup, numbers/dates            │
│                                                                        │
│  5. Translation memory build                                           │
│     • For every glossary term + detected proper noun: list of all      │
│       renderings with paragraph indices                                │
│     • Compute consistency status per term                              │
│                                                                        │
│  6. Boundary/completeness check                                        │
│     • LLM call per: doc start, doc end, chunk boundaries               │
│     • Strictly compares completeness, not style                        │
│                                                                        │
│  7. LLM strict audit (per chunk + global context)                      │
│     • Sees: source chunk, target chunk, document brief, glossary,      │
│             relevant TM snapshot, boundary segments, programmatic      │
│             findings already detected                                  │
│     • Returns: candidate suggestions with strict schema                │
│                                                                        │
│  8. Strict validation filter (server-side, no LLM)                     │
│     • Anchor verification, similarity threshold, generic-rationale     │
│       blacklist, severity/category match, per-paragraph cap            │
│     → drops 60-80% of LLM candidates                                   │
│                                                                        │
│  9. Review queue assembly                                              │
│     • Grouped by paragraph, sorted by severity                         │
│     • Bulk actions available: critical-only, consistency-only          │
└────────────────────────────────────────────────────────────────────────┘
```

### 1.3. Modes

Δύο ορθογώνιες διαστάσεις:

**Translation mode** (επηρεάζει το generation):

| mode                     | prescan  | radar | profile detect | drift sentinel | polish pass |
|--------------------------|----------|-------|----------------|----------------|-------------|
| `standard`               | v2-lite  | off   | basic          | off            | off         |
| `premium-literary`       | v2-full  | on    | strict         | on             | on          |
| `premium-academic`       | v2-full  | off   | strict         | on             | off         |
| `premium-legal`          | v2-full  | off   | strict         | on             | off         |
| `premium-theological`    | v2-full  | on    | strict         | on             | off         |
| `premium-historical`     | v2-full  | on    | strict         | on             | off         |

**Review mode** (επηρεάζει τι βλέπει ο χρήστης μετά):

| mode                  | shows                                                         |
|-----------------------|---------------------------------------------------------------|
| `critical-only`       | severity=critical (μόνο)                                       |
| `strict` (default)    | critical + major + auto-applicable consistency + completeness |
| `full-strict`         | όλα όσα πέρασαν validation                                     |

Default συνδυασμός: `standard` + `strict`.

---

## 2. Σκέλος Α — Βελτίωση παραγωγής μετάφρασης

### 2.1. Prescan v2

Τρία passes, με conditional fast path.

**Pass A — Classification (πάντα)**

Ίδιο σχεδόν με το τρέχον αλλά με δύο αλλαγές:
- Ζητάμε `primary_profile` και `secondary_profile` (literary, academic, legal,
  theological, historical, journalistic, technical) — όχι πια ελεύθερο
  `style_register`.
- Ζητάμε `risk_flags`: structured booleans αντί για ελεύθερο κείμενο.

Output schema:
```json
{
  "source_language": "English",
  "primary_profile": "literary",
  "secondary_profile": "historical",
  "subject": "βιογραφία αμερικανού συγγραφέα του 19ου αι.",
  "era_context": "19ος αιώνας, Νέα Αγγλία",
  "narrative_tone": "ειρωνικός, αυτοβιογραφικός",
  "risk_flags": {
    "has_idioms": true,
    "has_archaic_register": false,
    "has_cultural_references": true,
    "has_wordplay_or_irony": true,
    "has_biblical_quotes": false,
    "has_legal_terminology": false,
    "has_dialects": false,
    "has_technical_terminology": false
  },
  "translation_notes": "ελεύθερο κείμενο, max 200 λέξεις"
}
```

**Pass B — Terminology sweep (πάντα)**

Όχι μόνο σε ένα sample. Σαρώνουμε *όλο* το κείμενο σε chunks των ~30k chars
(non-overlapping), ζητάμε από τον LLM glossary candidates ανά chunk, και τους
συγχωνεύουμε σε ένα structured glossary με frequency counting και first
occurrence.

Έτσι ένα όνομα που εμφανίζεται μόνο μετά τη σελίδα 80 (αλλά εμφανίζεται 12 φορές)
δεν χάνεται — πράγμα που τώρα γίνεται με το `sample[:80000]`.

**Pass C — Risk register (μόνο αν υπάρχει risk flag)**

Νέο pass. Σαρώνει το κείμενο σε ίδια chunks και επιστρέφει συγκεκριμένα δύσκολα
σημεία (idioms, allusions, wordplay, ironic passages) με source_span,
paragraph_index_estimate, type, gloss, και translation_hint. Αυτό γίνεται input
στο hard-passage radar αργότερα.

Output:
```json
[
  {
    "paragraph_index_estimate": 12,
    "source_span": "He was over the moon when he saw...",
    "type": "idiom",
    "gloss": "extremely happy",
    "translation_hint": "πρότεινε ελληνικό ισοδύναμο, π.χ. «δεν πατούσε στη γη»",
    "literal_translation_warning": "ΜΗΝ μεταφράσεις «πάνω από το φεγγάρι»"
  },
  {
    "paragraph_index_estimate": 47,
    "source_span": "Like Caesar's wife",
    "type": "allusion",
    "gloss": "must be above suspicion",
    "translation_hint": "διατήρησε τον υπαινιγμό, μη τον εξηγείς",
    "literal_translation_warning": null
  }
]
```

**Σημείωση εφαρμογής**: το `paragraph_index_estimate` είναι κατά προσέγγιση —
στη φάση generation το hard-passage radar επικυρώνει αν το source_span όντως
βρίσκεται στο chunk πριν προωθηθεί.

### 2.2. Profile-driven system prompts

Αντί για if/elif μέσα σε ένα prompt με τμήματα `style_instructions`, δημιουργούμε
έξι αυτόνομα system prompts (ένα ανά profile) + έναν blender για mixed
περιπτώσεις.

Όλα μοιράζονται ένα **κοινό core** που περιέχει:

```
ΚΟΙΝΟΙ ΚΑΝΟΝΕΣ (ισχύουν πάντα):
1) Δεν προσθέτεις ούτε αφαιρείς πληροφορίες. Πιστή απόδοση νοήματος.
2) Διατηρείς ΑΚΡΙΒΩΣ αριθμό και σειρά παραγράφων.
3) Κύρια ονόματα, ημερομηνίες, ποσά και τίτλοι: 100% ακρίβεια.
4) Tags [B]/[I]/[U] παραμένουν στη θέση τους.
5) Εισαγωγικά πάντα ελληνικά « ». Ποτέ " " ή ' '.
6) Καμία σημείωση μεταφραστή στο κείμενο.
```

Και έχουν **ειδικά τμήματα** ανά profile.

#### 2.2.1. LITERARY profile

```
ΛΟΓΟΤΕΧΝΙΚΟ ΥΦΟΣ — Ιεραρχία:
1. Πραγματικό νόημα (όχι κατά λέξη)
2. Φυσικός ελληνικός λογοτεχνικός λόγος
3. Διατήρηση φωνής, ρυθμού, ειρωνείας, ατμόσφαιρας

ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ:
- Ιδιώματα, μεταφορές, λογοπαίγνια: ΠΟΤΕ κατά λέξη.
  Βρες λειτουργικό ελληνικό αντίστοιχο. Αν δεν υπάρχει, αναδιατύπωσε
  διατηρώντας το νόημα και το αποτέλεσμα στον αναγνώστη.
- Όταν η αγγλική σύνταξη ακούγεται ξένη στα ελληνικά, ΑΝΑΔΟΜΗΣΕ τη φράση.
  Δεν υποχρεούσαι να μιμηθείς τη σύνταξη του πρωτοτύπου.
- Ειρωνεία, χιούμορ, αμφισημία: ΔΙΑΤΗΡΗΣΕ. Μην εξομαλύνεις.
- Ιδιορρυθμίες του συγγραφέα (ασυνήθιστες παρομοιώσεις, επαναλήψεις,
  μακροπερίοδος): διατήρησέ τες.

ΑΠΑΓΟΡΕΥΕΤΑΙ:
- Εκσυγχρονισμός που εξαφανίζει την εποχή του πρωτοτύπου.
- Ψευδολόγια λύση όταν το πρωτότυπο είναι απλό.
- Ακαδημαϊκές/εξηγηματικές παρενθέσεις.
- Μετατροπή έντονου ύφους σε επίπεδο πεζογραφικό.
- Λεξιλογικός υπερτροφισμός ή ποιητικισμοί που δεν υπάρχουν στο πρωτότυπο.

ΟΤΑΝ ΔΥΣΚΟΛΕΥΤΕΙΣ:
- Σκέψου τι θα έκανε ένας έμπειρος Έλληνας λογοτεχνικός μεταφραστής
  σε επαγγελματικό εκδοτικό περιβάλλον.
- Προτίμησε τη σημασιολογικά ασφαλή λύση όταν αμφιβάλλεις.
- Σε αμφισημία, κράτησε την αμφισημία· μη τη λύσεις αυθαίρετα.
```

#### 2.2.2. ACADEMIC profile

```
ΑΚΑΔΗΜΑΪΚΟ ΥΦΟΣ — Ιεραρχία:
1. Ακρίβεια ορολογίας
2. Σαφήνεια επιχειρηματολογίας
3. Σοβαρός, φυσικός ελληνικός επιστημονικός λόγος

ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ:
- Καθιερωμένη ελληνική ορολογία όπου υπάρχει.
- Όπου δεν υπάρχει αδιαμφισβήτητη ελληνική απόδοση, κράτα τον αγγλικό όρο
  σε παρένθεση μετά την προτεινόμενη απόδοση: «η ισχυρή υπόθεση
  (strong hypothesis)» — μόνο στην πρώτη εμφάνιση.
- Τεχνικά παραθέματα, ονομασίες θεωρημάτων, κανόνες: ΠΑΝΤΑ καθιερωμένη μορφή.

ΑΠΑΓΟΡΕΥΕΤΑΙ:
- Λογοτεχνικές ελευθερίες, μεταφορές που δεν υπάρχουν στο πρωτότυπο.
- Απλούστευση τεχνικού νοήματος για χάρη ροής.
- Κατάχρηση παθητικής φωνής εκεί που το πρωτότυπο χρησιμοποιεί ενεργητική.

ΕΠΙΣΗΜΑΙΝΕΙΣ (στις σημειώσεις, όχι στο κείμενο):
- Όρους που χρειάζονται υποσημείωση μεταφραστή.
- Όρους όπου η ελληνική απόδοση δεν είναι παγιωμένη.
```

#### 2.2.3. LEGAL profile

```
ΝΟΜΙΚΟ ΥΦΟΣ — Ιεραρχία:
1. Ακρίβεια νομικής ορολογίας
2. Τυπικότητα και ομοιομορφία
3. Αναγνωσιμότητα

ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ:
- Καθιερωμένη ελληνική νομική ορολογία (νόμοι, θεσμοί, διαδικασίες).
- Ονομασίες θεσμών που ΔΕΝ υπάρχουν στο ελληνικό δίκαιο: διατηρούνται
  μεταγεγραμμένες με τον αγγλικό όρο σε παρένθεση πρώτη φορά.
- Λατινικές νομικές φράσεις (mens rea, habeas corpus, κ.λπ.): διατηρούνται
  ως έχουν, με σύντομη επεξήγηση σε υποσημείωση αν δεν είναι πασίγνωστες.
- Νομοθετικές παραπομπές: ακριβής αρίθμηση και τυποποιημένη μορφή.

ΑΠΑΓΟΡΕΥΕΤΑΙ:
- Κάθε λογοτεχνική ελευθερία.
- Παράφραση επίσημης διατύπωσης.
- Συγχώνευση παραγράφων ή σημείων αρίθμησης.
```

#### 2.2.4. THEOLOGICAL profile

```
ΘΕΟΛΟΓΙΚΟ ΥΦΟΣ — Ιεραρχία:
1. Καθιερωμένη θεολογική και εκκλησιαστική ορολογία
2. Σοβαρός υψηλός λόγος, χωρίς αρχαϊσμούς
3. Πιστότητα στο πρωτότυπο

ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ:
- Πατερικά παραθέματα: από τα πρωτότυπα κείμενα ή την καθιερωμένη
  νεοελληνική απόδοση, ποτέ μέσω αγγλικής μετάφρασης.
- Βιβλικά παραθέματα: σύμφωνα με την νεοελληνική μετάφραση της Καινής
  Διαθήκης (κειμενοκεντρική) εκτός αν το συγκεκριμένο έργο χρησιμοποιεί
  άλλη — που τότε δηλώνεται.
- Ορολογία: «οικονομία», «ενανθρώπηση», «θέωση», «ομοούσιος», κ.λπ. —
  πάντα στην καθιερωμένη ορθόδοξη μορφή.
- Ονόματα Πατέρων και Αγίων: παγιωμένη ελληνική μορφή.

ΑΠΑΓΟΡΕΥΕΤΑΙ:
- Παράφραση πατερικών αποσπασμάτων.
- Καθαρευουσιάνικα όπου ο συγγραφέας γράφει σε σύγχρονο λόγο.
- Χρήση «Θεός» αντί συγκεκριμένου «Πατήρ»/«Υιός»/«Πνεύμα» όταν το
  πρωτότυπο διακρίνει.
```

#### 2.2.5. HISTORICAL profile

```
ΙΣΤΟΡΙΚΟ ΥΦΟΣ — Ιεραρχία:
1. Ακρίβεια ιστορικών δεδομένων (πρόσωπα, τόποι, χρονολογίες, θεσμοί)
2. Σοβαρός αλλά προσιτός ελληνικός λόγος
3. Διατήρηση ύφους πρωτοτύπου

ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ:
- Ονόματα ιστορικών προσώπων: ΠΑΓΙΩΜΕΝΗ ελληνική μορφή
  (π.χ. «Καρλομάγνος», όχι «Σαρλεμάν»). Όπου δεν υπάρχει παγιωμένη
  μορφή, μεταγραφή με συνέπεια.
- Τοπωνύμια: παγιωμένη ελληνική μορφή για κλασικά τοπωνύμια.
- Θεσμοί άλλων εποχών/πολιτισμών: μεταγραφή ή καθιερωμένη ελληνική
  απόδοση. Ποτέ αυτοσχεδιασμός.
- Χρονολογίες, ηγεμονίες, μάχες: 100% ακρίβεια.

ΑΠΑΓΟΡΕΥΕΤΑΙ:
- Σύγχρονοι όροι για παλαιούς θεσμούς (π.χ. «πρόεδρος» για Ρωμαίο consul).
- Ανακρίβειες σε χρονολογίες ή γεωγραφία.
```

#### 2.2.6. Mixed profiles

Όταν `secondary_profile != null`, χρησιμοποιείται blended prompt: ο πρωτεύων
profile καθορίζει την ιεράρχηση και τους ΑΠΑΓΟΡΕΥΕΤΑΙ-κανόνες, ο δευτερεύων
προσθέτει τους ΑΠΑΡΑΒΑΤΟΥΣ ΚΑΝΟΝΕΣ του (deduplicated).

Παράδειγμα: literary + historical = literary core, αλλά εφαρμόζονται οι
ιστορικοί κανόνες για ονόματα/τοπωνύμια/θεσμούς.

### 2.3. Hard-passage radar (per chunk, premium modes only)

Πριν την κανονική μετάφραση κάθε chunk, ένα γρήγορο pass τρέχει αν:
- Το mode είναι premium-literary, premium-theological ή premium-historical, ΚΑΙ
- Το chunk περιέχει τουλάχιστον ένα paragraph_index_estimate από το risk
  register, Ή
- Ένα γρήγορο pattern match εντοπίζει markers (εισαγωγικά, biblical κεφαλαία,
  «as if», «like…», ιδιωματικά verbs).

Το radar prompt:

```
Είσαι αναλυτής μετάφρασης. ΔΕΝ μεταφράζεις.
Σου δίνω ένα κείμενο σε [SOURCE_LANGUAGE].
Εντόπισε ΜΟΝΟ τα σημεία που είναι επικίνδυνα για κατά λέξη μετάφραση
στα ελληνικά:
- ιδιώματα
- λογοτεχνικοί/πολιτισμικοί υπαινιγμοί
- λογοπαίγνια / ομώνυμα
- ειρωνεία ή σαρκασμός που χάνεται κατά λέξη
- false friends (λέξεις που μοιάζουν με ελληνικές αλλά σημαίνουν άλλο)
- αμφίσημες αναφορές προσώπου ή χρόνου
- εκφράσεις που εκφέρονται ως quote και έχουν δικό τους νόημα

ΓΙΑ ΚΑΘΕ ΣΗΜΕΙΟ:
- δώσε το ακριβές source_span (verbatim από το κείμενο)
- ταξινόμησε: idiom | allusion | wordplay | irony | false_friend |
  ambiguous_referent | quoted_expression | cultural_reference
- εξήγησε σε 5-10 λέξεις τι σημαίνει πραγματικά
- δώσε ένα translation_hint: τι θέλω να *ΜΗΝ* κάνει ο μεταφραστής

ΑΥΣΤΗΡΑ:
- Αν δεν υπάρχουν δύσκολα σημεία, επέστρεψε [].
- ΜΗΝ προσθέτεις σημεία επειδή «θα μπορούσαν να είναι δύσκολα».
- Επικεντρώσου σε σημεία όπου η κατά λέξη απόδοση θα παρήγαγε σημασιολογικό
  ή υφολογικό πρόβλημα.

OUTPUT: μόνο JSON array.

[
  {
    "source_span": "...",
    "type": "...",
    "gloss": "...",
    "translation_hint": "..."
  }
]

ΚΕΙΜΕΝΟ:
<<<
{chunk_content}
>>>
```

Το αποτέλεσμα μπαίνει στο translation prompt ως `<HEADS_UP>` block (βλ. 2.4).

### 2.4. Translation prompt v2 (chunk-level)

System prompt = profile-specific (από 2.2) + glossary block (filtered by lock).

User prompt:

```
Μετάφρασε ΜΟΝΟ το παρακάτω κείμενο. Δώσε ΜΟΝΟ τη μετάφραση.
Ένα προς ένα paragraph, χωρισμένα με κενή γραμμή.

[ΕΑΝ ΥΠΑΡΧΕΙ CONTEXT:]
ΠΡΟΗΓΟΥΜΕΝΟ ΠΛΑΙΣΙΟ (μόνο για συνέχεια ύφους — ΜΗΝ μεταφράσεις ξανά):
<<<
{previous_translation_tail}
>>>

[ΕΑΝ ΥΠΑΡΧΕΙ HARD-PASSAGE RADAR:]
ΠΡΟΣΟΧΗ — δύσκολα σημεία σε αυτό το chunk:
{radar_findings_formatted}

Για ΚΑΘΕ τέτοιο σημείο, χρησιμοποίησε λειτουργική ελληνική απόδοση
και ΟΧΙ κατά λέξη.

[ΕΑΝ ΥΠΑΡΧΕΙ TM SNAPSHOT για όρους που εμφανίζονται σε αυτό το chunk:]
ΗΔΗ ΑΠΟΔΟΘΕΝΤΕΣ ΟΡΟΙ (διατήρησε ΙΔΙΕΣ αποδόσεις):
{tm_snapshot}

ΚΕΙΜΕΝΟ ΠΡΟΣ ΜΕΤΑΦΡΑΣΗ:
<<<
{chunk_content}
>>>
```

Το `tm_snapshot` αναβαθμίζει το glossary enforcement: αντί να ελπίζουμε ότι
το post-processing find-replace θα κάνει τη δουλειά, βάζουμε στον LLM να
χρησιμοποιήσει σωστή απόδοση εξαρχής. Σχηματίζεται σε κάθε chunk με βάση τι
glossary terms εμφανίζονται στο chunk + τι αποδόσεις τους έχουμε ήδη βάλει σε
προηγούμενα chunks (από την translation memory που χτίζουμε live).

### 2.5. In-pipeline critique pass (tightened, auto-fix only)

Σημαντική αλλαγή: ο in-pipeline critique τώρα έχει *ξεκάθαρο, στενό ρόλο*:

> «Βρες μόνο τα προβλήματα που μπορούν να διορθωθούν με ασφάλεια
> από τον επόμενο pass. Δεν είσαι ο τελικός κριτής ποιότητας.»

Αυτό σημαίνει: εστιάζει σε factual/structural λάθη, όχι σε υφολογικά.

```
Είσαι κριτής μετάφρασης που εντοπίζει ΜΟΝΟ προβλήματα που πρέπει να
διορθωθούν αυτόματα στο επόμενο βήμα. ΔΕΝ είσαι ο τελικός ποιοτικός
έλεγχος — αυτός γίνεται αργότερα.

ΕΣΤΙΑΖΕΣΑΙ ΣΕ:
1. Παράλειψη: λείπει πρόταση/ονοματική φράση/αριθμητικό από το πρωτότυπο.
2. Προσθήκη: η μετάφραση έχει νόημα που δεν υπάρχει στο πρωτότυπο.
3. Λάθος αριθμός/ημερομηνία/κύριο όνομα.
4. Σαφώς λάθος απόδοση όρου που υπάρχει στο γλωσσάρι.
5. Tags [B]/[I]/[U] που χάθηκαν ή μετακινήθηκαν.
6. Καθαρή αντιστροφή νοήματος (π.χ. αρνητικό έγινε καταφατικό).
7. Καθαρό false friend (η ελληνική λέξη σημαίνει εντελώς άλλο).

ΔΕΝ ΕΣΤΙΑΖΕΣΑΙ ΣΕ (αυτά πάνε στον τελικό audit):
- Στιλιστικές προτιμήσεις
- «Πιο φυσική» απόδοση όταν η τρέχουσα δεν είναι λάθος
- Ροή/ρυθμός
- Συντακτικές αναδιατάξεις χωρίς νοηματικό όφελος
- Ιδιωματικές προτιμήσεις

ΓΙΑ ΚΑΘΕ ΠΡΟΒΛΗΜΑ:
- severity: "critical" | "major"  (όχι "minor" εδώ)
- type: "omission" | "addition" | "factual" | "glossary" | "formatting"
        | "inversion" | "false_friend"
- source_span: ακριβής φράση από πρωτότυπο
- translated_span: ακριβής φράση από μετάφραση (ή null για omission)
- suggested_fix: η διόρθωση
- rationale: ΣΥΓΚΕΚΡΙΜΕΝΗ (όχι «πιο φυσικό», «καλύτερα»)

Αν δεν υπάρχουν τέτοια προβλήματα: {"issues": [], "chunk_confidence": "high"}

OUTPUT: μόνο JSON.
{
  "issues": [...],
  "chunk_confidence": "high" | "medium" | "low"
}
```

**Κρίσιμη διαφορά από το παλιό prompt**: εξαλείφονται τα `low` severity και τα
γκρίζα categories όπως `register` και `literalism`. Αυτά πάνε αποκλειστικά στο
post-translation audit (Σκέλος Β), όπου περνούν από strict validation.

### 2.6. Drift sentinel (κάθε N chunks)

Σε premium modes, κάθε 10 chunks (configurable) τρέχει ένα μικρό sentinel call
που συγκρίνει chunks 1-3 με τα πιο πρόσφατα 3:

```
Σου δίνω αποσπάσματα από αρχή και τέλος της ίδιας μετάφρασης.
Διαφέρει το ύφος, η φόρμα ή η ποιότητα; Απάντησε σύντομα και ΜΟΝΟ σε JSON:

{
  "drift_detected": true | false,
  "type": "register_shift" | "consistency_drop" | "literalism_increase" | null,
  "examples": ["..."],
  "recommendation": "..."  // π.χ. "lower temperature", "reload glossary into context"
}

ΑΡΧΗ:
{first_chunks}

ΠΡΟΣΦΑΤΟ:
{recent_chunks}
```

Το αποτέλεσμα δεν επιτρέπεται να αλλάξει ήδη μεταφρασμένα chunks αυτόματα — αν
detected drift, το flag εμφανίζεται στον audit ως system warning ώστε να
ενημερώνει τον χρήστη.

### 2.7. Glossary v2 schema

Δομημένο, με `category` και `lock`.

```json
{
  "id": "uuid-v4",
  "source": "London",
  "target": "Λονδίνο",
  "category": "place",
  "lock": "strict",
  "frequency": 23,
  "first_occurrence_paragraph": 4,
  "examples_of_use": [
    "He moved to London in 1872",
    "The London branch opened earlier"
  ],
  "alternatives_considered": [],
  "needs_footnote": false,
  "translator_note": null
}
```

**Categories**:
- `person` — όνομα προσώπου
- `place` — τοπωνύμιο
- `org` — οργανισμός/ίδρυμα/εταιρεία
- `title` — τίτλος έργου (βιβλίο, τραγούδι, ταινία)
- `term-technical` — τεχνικός όρος
- `term-legal` — νομικός όρος
- `term-theological` — θεολογικός όρος
- `term-historical` — ιστορικός όρος (θεσμός εποχής, αξίωμα)
- `recurring-phrase` — επαναλαμβανόμενη χαρακτηριστική έκφραση
- `idiom-translation` — ιδιωματική απόδοση που έχει επιλεγεί
- `fixed-expression` — πάγια ορολογία ή λεκτικό σχήμα

**Locks**:
- `strict` — πάντα ίδια απόδοση, post-processing find-replace ενεργό.
- `flexible` — ίδια απόδοση αλλά επιτρέπεται κλίση/προσαρμογή στο context.
  Post-processing απενεργό· επιτηρείται μόνο από consistency audit.
- `transliterate` — μην το μεταφράσεις, μετάγραψέ το.
- `do_not_translate` — άφησέ το ως έχει στο αλφάβητο πηγής.

**Default rules** για το lock:
- `person`, `place` (well-established) → `strict`
- `org`, `title` → `strict`
- `term-legal`, `term-theological` → `strict`
- `term-technical` → `flexible` (μπορεί να κλιθεί στις πτώσεις)
- `recurring-phrase` → `flexible`
- `idiom-translation` → `flexible`
- `fixed-expression` → `strict`
- Νέοι/μη παγιωμένοι όροι → `flexible` με `needs_footnote: true`

**Σημαντικό για literary mode**: post-processing find-replace τρέχει ΜΟΝΟ σε
entries με `lock: strict`. Αυτό αντικαθιστά την υπάρχουσα μαύρη-λίστα λογική
(όπου σε literary mode πετάς όλα εκτός από person/place/org/title) — τώρα η
ίδια η entry δηλώνει αν αξίζει αυστηρή επιβολή.

---

## 3. Σκέλος Β — Strict post-translation audit

Νέα φάση που τρέχει αφού ολοκληρωθεί όλο το translation phase. Πέντε διαδοχικά
βήματα. Καθένα δίνει input στο επόμενο.

### 3.1. Phase 1 — Programmatic checks (no LLM)

Ντετερμινιστικοί έλεγχοι, εκτελούνται σε δευτερόλεπτα, παράγουν concrete
findings που στη συνέχεια τροφοδοτούν τον LLM audit.

| Check | Λογική | Έξοδος findings |
|-------|--------|-----------------|
| `paragraph_count` | len(source) vs len(target) | mismatch με paragraph indices |
| `length_ratio` | για κάθε para: char_ratio target/source | outliers (ratio < 0.5 ή > 2.5 ανάλογα γλώσσα) |
| `empty_target` | target paragraph empty αλλά source non-empty | paragraph indices |
| `markup_consistency` | count [B]/[I]/[U] tags ανά paragraph | mismatches |
| `numbers_preservation` | extract digits/dates/percentages από source, check όλα στο target | missing numbers |
| `proper_noun_preservation` | extract capitalized non-stop-words από source, normalize, check στο target | candidates που λείπουν |
| `quote_consistency` | έλεγχος αν εισαγωγικά ταιριάζουν σε ζεύγη και στο σωστό alphabet | mismatches |
| `glossary_match` | για κάθε strict glossary entry, verify ότι target term εμφανίζεται όταν source term εμφανίζεται | uncovered occurrences |
| `markup_position` | tag positions εντός paragraph (boundary check) | drifts |

Output schema (programmatic findings):
```json
{
  "paragraph_count_mismatch": false,
  "findings": [
    {
      "paragraph_index": 12,
      "type": "missing_number",
      "details": "source contains '1872', target has no '1872'"
    },
    {
      "paragraph_index": 47,
      "type": "missing_glossary_term",
      "details": "source has 'London' (3 occurrences), target has only 1 'Λονδίνο'"
    }
  ]
}
```

### 3.2. Phase 2 — Translation memory build & consistency analysis

Δομούμε ένα TM dictionary για όλο το έργο:

```json
{
  "term_id": "uuid",
  "source_term": "London",
  "category": "place",
  "lock": "strict",
  "occurrences": [
    {"paragraph": 4,  "rendering": "Λονδίνο"},
    {"paragraph": 17, "rendering": "Λονδίνου"},
    {"paragraph": 45, "rendering": "Λοντίνο"}
  ],
  "canonical_target": "Λονδίνο",
  "unique_renderings_normalized": 2,
  "consistency_status": "inconsistent",
  "expected_inflections": ["Λονδίνο", "Λονδίνου", "Λονδίνω"],
  "anomalous_renderings": [
    {"paragraph": 45, "rendering": "Λοντίνο"}
  ]
}
```

Η normalization αφαιρεί τόνους και κανονικοποιεί τις πτώσεις (Greek stemmer)
ώστε «Λονδίνο» και «Λονδίνου» να ομαδοποιούνται ως ίδια ρίζα. Anomalous μένει
μόνο όταν η ρίζα διαφέρει.

Η ίδια λογική εφαρμόζεται και σε:
- Detected proper nouns που δεν είναι στο glossary (auto-extracted)
- Recurring phrases (occurrences ≥ 3)

Inconsistencies από αυτή τη φάση τροφοδοτούν τον LLM audit ως concrete
candidates ΑΛΛΑ και βγάζουν direct suggestions για bulk-apply.

### 3.3. Phase 3 — Boundary/completeness check

Ειδικά LLM calls μόνο για boundary regions:

- **Document start**: πρώτη παράγραφος vs πρώτη παράγραφος μετάφρασης
- **Document end**: τελευταία παράγραφος (και η προτελευταία) — εκεί συμβαίνουν
  οι περισσότερες σιωπηλές περικοπές
- **Chunk boundaries**: τελευταία πρόταση κάθε chunk + πρώτη πρόταση επόμενου
  chunk vs τα αντίστοιχα του πρωτοτύπου

Boundary prompt:

```
Σου δίνω συγκεκριμένα boundary segments από πρωτότυπο και μετάφραση.
Έλεγξε ΑΥΣΤΗΡΑ ΜΟΝΟ:
1) Λείπει αρχή πρότασης ή αρχή παραγράφου από τη μετάφραση;
2) Λείπει τέλος πρότασης ή τέλος παραγράφου από τη μετάφραση;
3) Λείπει ολόκληρη πρόταση;
4) Έχει προστεθεί στη μετάφραση πρόταση που δεν υπάρχει στο πρωτότυπο;

ΔΕΝ ΕΛΕΓΧΕΙΣ:
- ύφος, ροή, λεξιλόγιο
- σύνταξη όταν το νόημα είναι εκεί
- μικρές προσαρμογές για φυσικότητα

OUTPUT: μόνο JSON.

{
  "issues": [
    {
      "type": "missing_start" | "missing_end" | "missing_sentence" | "added_sentence",
      "source_span": "...",
      "translated_span": "..." | null,
      "missing_content": "..." | null,
      "severity": "critical" | "major"
    }
  ]
}

ΠΡΩΤΟΤΥΠΟ (boundary):
<<<
{source_boundary}
>>>

ΜΕΤΑΦΡΑΣΗ (boundary):
<<<
{target_boundary}
>>>
```

### 3.4. Phase 4 — LLM strict audit (per chunk + global context)

Αυτός είναι ο **κεντρικός νέος prompt**. Τρέχει per chunk, αλλά κάθε call
βλέπει global context για να μπορεί να κρίνει consistency.

System prompt:

```
Είσαι ανώτερος επιμελητής εκδόσεων με 20ετή εμπειρία στη μετάφραση
[SOURCE_LANGUAGE]→Ελληνικά. Ο ρόλος σου ΔΕΝ είναι να ξαναγράψεις τη
μετάφραση. Είναι να εντοπίσεις ΜΟΝΟ ΠΡΟΒΛΗΜΑΤΑ που πραγματικός εκδότης
θα διόρθωνε.

Η εφαρμογή έχει ήδη πιάσει αυτόματα: omissions, additions, λάθη αριθμών,
glossary mismatches, markup. ΜΗΝ τα ξαναπιάνεις.

ΕΣΥ ΕΠΙΣΗΜΑΙΝΕΙΣ ΜΟΝΟ:
A. Σημασιολογικά λάθη που δεν είναι προφανή omissions/additions
   (μετατόπιση νοήματος, false friend, λάθος υποκείμενο, λάθος χρόνος,
   αλλαγή σχέσης προσώπων).
B. Inversions: αρνητικό έγινε καταφατικό ή το αντίστροφο.
C. Καθαρά αφύσικη ελληνική φράση που πραγματικά δυσκολεύει αναγνώστη
   (όχι «θα μπορούσε να γίνει πιο φυσική»).
D. Αγγλισμός που χαλάει τη φράση (όχι απλή προτίμηση).
E. Καθαρό register shift: το πρωτότυπο είναι λογοτεχνικό και η μετάφραση
   ακαδημαϊκή ή ανάποδα.
F. Ασυνέπεια ορολογίας/ονομάτων (η εφαρμογή σου δίνει list με known
   inconsistencies — παίρνεις decision αν είναι ίδιος όρος ή όχι).
G. Λανθασμένη απόδοση τεχνικού/νομικού/θεολογικού/ιστορικού όρου.
H. Ορθογραφικά/τονισμός/στίξη: ΜΟΝΟ όταν είναι λάθος, όχι προτίμηση.
I. Όροι που χρειάζονται ανθρώπινη απόφαση (terminology_review): δεν
   προτείνεις διόρθωση, μόνο επισημαίνεις.

ΑΥΣΤΗΡΟΙ ΚΑΝΟΝΕΣ:

1. Δεν προτείνεις αλλαγή για σωστές φράσεις.
2. Δεν αντικαθιστάς συνώνυμα (π.χ. «καλός» → «ωραίος»). Αυτό είναι
   προτίμηση, όχι λάθος.
3. Δεν προτείνεις «πιο κομψή» ή «πιο ρέουσα» διατύπωση όταν η τρέχουσα
   είναι ορθή.
4. Δεν προτείνεις αλλαγή σύνταξης χωρίς νοηματικό όφελος.
5. Κάθε πρόταση ΠΡΕΠΕΙ να αναφέρει ΣΥΓΚΕΚΡΙΜΕΝΟ γλωσσικό γεγονός στο
   rationale (τι ακριβώς είναι λάθος γλωσσικά). Όχι «πιο φυσικό»,
   «καλύτερα», «βελτίωση».
6. Severity:
   - "critical" = σοβαρό σημασιολογικό λάθος που ένας εκδότης ΔΕΝ θα
     άφηνε να περάσει σε έντυπο
   - "major" = καθαρό λάθος αλλά όχι σημασιολογική καταστροφή
   - "minor" = πραγματικό λάθος αλλά μικρής έκτασης (π.χ. λάθος τόνος,
     αδέξια στίξη). ΔΕΝ ΧΡΗΣΙΜΟΠΟΙΕΙΣ "minor" ΓΙΑ ΥΦΟΛΟΓΙΚΑ.
7. Για κάθε πρόταση, source_span είναι verbatim από το πρωτότυπο,
   current_translation είναι verbatim από τη μετάφραση. Αν δεν μπορείς
   να τα δώσεις verbatim, ΜΗΝ εκδώσεις την πρόταση.
8. confidence: float 0.0-1.0. Αν < 0.7, ΜΗΝ εκδώσεις την πρόταση.

ΠΑΡΑΔΕΙΓΜΑΤΑ ΑΥΤΩΝ ΠΟΥ ΘΕΛΩ:

✓ category: "mistranslation", severity: "critical"
  source_span: "She eventually agreed"
  current_translation: "Ενδεχομένως συμφώνησε"
  suggested_translation: "Τελικά συμφώνησε"
  rationale: "false friend: 'eventually' = τελικά, όχι ενδεχομένως"

✓ category: "consistency", severity: "major"
  source_span: "London"
  current_translation: "Λοντίνο"
  suggested_translation: "Λονδίνο"
  rationale: "ασυνέπεια: αλλού στο έργο 'Λονδίνο' (8 εμφανίσεις)"

✓ category: "inversion", severity: "critical"
  source_span: "He did not refuse"
  current_translation: "Αρνήθηκε"
  suggested_translation: "Δεν αρνήθηκε"
  rationale: "διπλή άρνηση→καταφατική μεταφράστηκε ως άρνηση"

ΠΑΡΑΔΕΙΓΜΑΤΑ ΑΥΤΩΝ ΠΟΥ ΑΠΟΡΡΙΠΤΟΝΤΑΙ:

✗ "πιο φυσική απόδοση"        — γενικό rationale
✗ "ωραιότερο", "πιο κομψό"     — προτίμηση
✗ "καλός" → "ωραίος"           — synonym swap
✗ "Θα μπορούσε να βελτιωθεί"   — όχι λάθος
✗ rationale χωρίς συγκεκριμένο γεγονός
```

User prompt:

```
ΕΓΓΡΑΦΟ:
{document_brief}

GLOSSARY (αποδόσεις σε χρήση):
{glossary_compact}

ΚΑΤΑΓΕΓΡΑΜΜΕΝΕΣ ΑΣΥΝΕΠΕΙΕΣ (από programmatic check):
{tm_inconsistencies_for_this_chunk}

CHUNK {N}/{M}.
Boundary info: αυτό είναι chunk {N} από {M}. {first | middle | last}.

ΠΡΩΤΟΤΥΠΟ:
<<<
{source_chunk}
>>>

ΜΕΤΑΦΡΑΣΗ:
<<<
{target_chunk}
>>>

Επέστρεψε JSON:

{
  "suggestions": [
    {
      "paragraph_index": <int, 1-indexed μέσα στο chunk>,
      "category": "mistranslation" | "inversion" | "register_shift"
                | "consistency" | "anglicism" | "mechanical"
                | "grammar" | "punctuation" | "terminology"
                | "terminology_review",
      "severity": "critical" | "major" | "minor",
      "source_span": "...",
      "current_translation": "...",
      "suggested_translation": "...",
      "rationale": "...",
      "confidence": 0.0-1.0,
      "consistency_group_hint": null | "...",
      "auto_applicable": true | false
    }
  ]
}

ΟΧΙ markdown, ΟΧΙ backticks. ΜΟΝΟ JSON.
```

### 3.5. Phase 5 — Strict validation filter (server-side, no LLM)

Όλα τα candidate suggestions από Phases 3 & 4 περνούν από αυτό το φίλτρο πριν
φτάσουν στο UI. Είναι το πιο σημαντικό κομμάτι της αρχιτεκτονικής για τον
στόχο «no false positives».

Κάθε suggestion ελέγχεται με τους εξής κανόνες (όλοι πρέπει να περάσουν):

| Κανόνας | Λογική |
|---------|--------|
| `anchor_source` | source_span πρέπει να βρίσκεται verbatim στο source paragraph (case-sensitive). |
| `anchor_target` | current_translation πρέπει να βρίσκεται verbatim στο target paragraph. |
| `not_too_similar` | normalized_levenshtein(suggested, current) ≥ 0.10. Πιο μικρή ομοιότητα → reject ως κοσμητική. |
| `concrete_rationale` | rationale ΔΕΝ ταιριάζει με regex blacklist (γενικά motherhood statements). |
| `category_severity_match` | severity δεν είναι "minor" όταν category είναι "anglicism" ή "mechanical" (αυτά απαιτούν τουλάχιστον "major" για να μη γεμίσει με κοσμητικά). |
| `confidence_threshold` | confidence ≥ 0.7. |
| `not_glossary_conflict` | suggested_translation δεν εισάγει νέο όρο που συγκρούεται με glossary entry άλλης απόδοσης. |
| `valid_categories_for_lock` | suggestions για όρους με `lock: do_not_translate` ή `transliterate` δεν επιτρέπονται από κανέναν category πλην `terminology_review`. |
| `not_duplicate` | δεν υπάρχει ήδη pending suggestion με ίδιο anchor (source_span + paragraph). |

**Generic-rationale blacklist** (regex match σε κανονικοποιημένο rationale):
```
πιο φυσικ
πιο κομψ
πιο ρέου
πιο ωραί
καλύτερη απόδοση
βελτίωση ύφους
ακούγεται καλύτερα
θα μπορούσε
θα ήταν προτιμότερ
ίσως καλύτερα
στιλιστικ
```

**Per-paragraph cap**: αν μετά το filtering μένουν > 3 suggestions για την ίδια
παράγραφο, κρατάμε τις 3 με το υψηλότερο severity score, με tiebreak στην
confidence. Αυτό αποτρέπει over-saturation που οδηγεί σε review fatigue.

**Severity score**: critical=3, major=2, minor=1.

Output schema του filtering:
```json
{
  "kept": 47,
  "dropped_anchor_source": 3,
  "dropped_anchor_target": 2,
  "dropped_too_similar": 18,
  "dropped_generic_rationale": 23,
  "dropped_low_confidence": 11,
  "dropped_per_paragraph_cap": 5,
  "dropped_glossary_conflict": 1,
  "dropped_severity_category_mismatch": 4
}
```

Αυτές οι μετρικές βγαίνουν στο logs για debugging. Στόχος: drop rate 50-80%
(αν είναι < 30%, ο LLM δεν είναι αρκετά αυστηρός· αν είναι > 90%, υπάρχει bug
στους validators).

### 3.6. Final suggestion schema (αυτό βλέπει το UI)

```json
{
  "id": "uuid-v4",
  "paragraph_index": 12,
  "chunk_index": 3,
  "category": "mistranslation",
  "severity": "critical",
  "source_span": "She eventually agreed",
  "current_translation": "Ενδεχομένως συμφώνησε",
  "suggested_translation": "Τελικά συμφώνησε",
  "rationale": "false friend: 'eventually' = τελικά, όχι ενδεχομένως",
  "confidence": 0.92,
  "consistency_group": null,
  "auto_applicable": true,
  "phase_origin": "llm_audit",
  "validation": {
    "anchor_source": true,
    "anchor_target": true,
    "not_too_similar": true,
    "concrete_rationale": true,
    "category_severity_match": true,
    "confidence_threshold": true,
    "not_glossary_conflict": true,
    "not_duplicate": true
  }
}
```

`phase_origin` ∈ {`programmatic`, `tm_consistency`, `boundary_check`, `llm_audit`}
— χρήσιμο για το UI ώστε να δείχνει το προέλευσης badge.

### 3.7. Bulk actions και UI organization

**Sort order στο review queue**:
1. severity DESC (critical πρώτα)
2. category priority (omission/inversion > consistency > terminology > grammar > punctuation)
3. paragraph_index ASC

**Bulk actions διαθέσιμα**:

| Button | Λειτουργία |
|--------|-----------|
| Apply all critical | Αποδέχεται ΟΛΑ τα severity=critical με `auto_applicable=true` |
| Apply all consistency | Αποδέχεται ΟΛΑ με category=consistency και auto_applicable=true |
| Apply all completeness | Αποδέχεται όλα τα completeness/missing_sentence (μόνο μετά confirmation) |
| Apply all from glossary mismatches | Mόνο programmatic glossary findings |

**Bulk actions ΠΟΥ ΔΕΝ ΥΠΑΡΧΟΥΝ** (απαγορευμένα by design):

- Apply all suggestions
- Apply all major
- Apply all style
- Apply all anglicisms

Αυτές οι ενέργειες πάντα απαιτούν per-suggestion accept.

**UI elements per suggestion**:
- Source span (highlighted στο source paragraph)
- Current translation (highlighted στο target paragraph)
- Suggested translation
- Category badge (color-coded ανά severity)
- Severity badge
- Rationale (κάτω από το suggestion)
- Confidence percentage (small)
- Phase origin badge (small, secondary color)
- Buttons: Accept · Edit · Reject
- Optional: «αλλαγές σε όλο το έργο» αν consistency_group != null

---

## 4. Συγκεντρωτικό σύνολο prompts

Όλα τα prompts σε ένα μέρος για ευκολία reference.

### 4.1. Prescan Pass A (classification)

```
Αναλύεις κείμενο που πρόκειται να μεταφραστεί στα Νέα Ελληνικά.
Διάβασε προσεκτικά και απάντησε ΜΟΝΟ σε JSON, χωρίς backticks.

ΣΧΗΜΑ:
{
  "source_language": "...",
  "primary_profile": "literary" | "academic" | "legal" | "theological"
                   | "historical" | "journalistic" | "technical",
  "secondary_profile": "..." | null,
  "subject": "1-2 προτάσεις",
  "era_context": "..." | null,
  "narrative_tone": "..." | null,
  "risk_flags": {
    "has_idioms": bool,
    "has_archaic_register": bool,
    "has_cultural_references": bool,
    "has_wordplay_or_irony": bool,
    "has_biblical_quotes": bool,
    "has_legal_terminology": bool,
    "has_dialects": bool,
    "has_technical_terminology": bool
  },
  "translation_notes": "..."
}

ΚΕΙΜΕΝΟ:
{text_sample}
```

### 4.2. Prescan Pass B (terminology sweep, ανά chunk)

```
Εξαγωγή ΟΛΩΝ των ονομάτων και επαναλαμβανόμενων όρων από το παρακάτω
απόσπασμα ({source_language}).

ΘΕΛΩ:
1. Ανθρώπους (πλήρη ονόματα).
2. Τόπους (πόλεις, χώρες, κτίρια, οδούς).
3. Οργανισμούς (εταιρείες, ιδρύματα, εκκλησίες).
4. Τίτλους έργων (βιβλία, τραγούδια, ταινίες, εφημερίδες).
5. Τεχνικούς/νομικούς/θεολογικούς/ιστορικούς όρους.
6. Επαναλαμβανόμενες χαρακτηριστικές φράσεις.

ΓΙΑ ΚΑΘΕ ΟΡΟ:
- source: ακριβής μορφή στο πρωτότυπο
- target: ελληνική απόδοση/μεταγραφή (παγιωμένη όπου υπάρχει)
- category: person | place | org | title | term-technical | term-legal
          | term-theological | term-historical | recurring-phrase
          | fixed-expression
- lock: strict | flexible | transliterate | do_not_translate
  (strict για παγιωμένα ονόματα/τοπωνύμια/τίτλους
   flexible για όρους που κλίνονται)
- needs_footnote: bool
- examples_of_use: [1-2 σύντομα contexts]

OUTPUT: μόνο JSON array. Όχι backticks.

ΚΕΙΜΕΝΟ:
{chunk}
```

### 4.3. Prescan Pass C (risk register)

```
Είσαι αναλυτής μετάφρασης. ΔΕΝ μεταφράζεις.
Διάβασε το παρακάτω κείμενο και εντόπισε σημεία που είναι ΕΠΙΚΙΝΔΥΝΑ
για κατά λέξη μετάφραση στα ελληνικά.

ΑΝΑΖΗΤΑΣ:
- ιδιώματα και πάγιες εκφράσεις της γλώσσας πηγής
- λογοτεχνικοί ή πολιτισμικοί υπαινιγμοί
- λογοπαίγνια, ομώνυμα, ηχητικά παίγνια
- ειρωνεία και σαρκασμός
- false friends
- αμφίσημες αναφορές (πρόσωπο, χρόνος, υποκείμενο)
- εκφράσεις που μέσα σε εισαγωγικά έχουν νόημα διαφορετικό από κυριολεκτικό

ΓΙΑ ΚΑΘΕ ΣΗΜΕΙΟ:
- source_span: verbatim από το κείμενο
- type: idiom | allusion | wordplay | irony | false_friend
      | ambiguous_referent | quoted_expression | cultural_reference
- gloss: τι σημαίνει στ' αλήθεια (5-10 λέξεις)
- translation_hint: σύντομη οδηγία τι ΝΑ ΜΗΝ κάνει ο μεταφραστής

ΑΥΣΤΗΡΑ:
- Αν δεν υπάρχουν, επέστρεψε [].
- ΜΗΝ προσθέτεις σημεία επειδή «θα μπορούσαν να είναι δύσκολα».
- Επικεντρώσου σε σημεία όπου η κατά λέξη απόδοση θα παρήγαγε λάθος.

OUTPUT: μόνο JSON array.

ΚΕΙΜΕΝΟ:
{chunk}
```

### 4.4. Translation system prompt (template, profile-specific)

```
Είσαι επαγγελματίας μεταφραστής {SOURCE_LANGUAGE}→Νέα Ελληνικά
για έκδοση βιβλίου. Δουλεύεις σε εκδοτικό περιβάλλον.

ΠΛΗΡΟΦΟΡΙΕΣ ΕΓΓΡΑΦΟΥ:
{document_brief}

ΚΟΙΝΟΙ ΚΑΝΟΝΕΣ:
1) Δεν προσθέτεις, δεν αφαιρείς, δεν συνοψίζεις, δεν αναδιατάσσεις.
2) Διατηρείς ΑΚΡΙΒΩΣ αριθμό και σειρά παραγράφων.
3) Κύρια ονόματα, ημερομηνίες, ποσά, τίτλοι: 100% ακρίβεια.
4) Tags [B]/[I]/[U] στις ΑΚΡΙΒΕΙΣ θέσεις τους.
5) Ελληνικά εισαγωγικά « » αποκλειστικά.
6) Καμία σημείωση μεταφραστή στο κείμενο.

[ΕΔΩ ΜΠΑΙΝΕΙ TO PROFILE-SPECIFIC BLOCK ΑΠΟ ΤΟ §2.2]

[ΕΔΩ ΜΠΑΙΝΕΙ TO GLOSSARY BLOCK]
ΓΛΩΣΣΑΡΙ (χρησιμοποίησε αυτές ΑΚΡΙΒΩΣ τις αποδόσεις):
{glossary_filtered_by_lock_strict_and_flexible}

Θέλω αποτέλεσμα έτοιμο για έκδοση χωρίς αλλοίωση περιεχομένου.
```

### 4.5. Translation user prompt

```
[CONTEXT_SECTION εάν υπάρχει previous chunk:]
ΠΡΟΗΓΟΥΜΕΝΟ ΠΛΑΙΣΙΟ (μόνο για συνέχεια ύφους — ΜΗΝ μεταφράσεις ξανά):
<<<
{previous_translation_tail}
>>>

[HEADS_UP_SECTION εάν υπάρχει radar findings:]
ΠΡΟΣΟΧΗ — δύσκολα σημεία σε αυτό το chunk:
{radar_findings_formatted_as_bullets}

Για ΚΑΘΕ τέτοιο σημείο: ΟΧΙ κατά λέξη απόδοση. Βρες λειτουργικό
ελληνικό ισοδύναμο.

[TM_SECTION εάν υπάρχουν επαναλαμβανόμενοι όροι:]
ΗΔΗ ΑΠΟΔΟΘΕΝΤΕΣ ΟΡΟΙ ΣΕ ΑΥΤΟ ΤΟ ΕΡΓΟ (ΧΡΗΣΙΜΟΠΟΙΗΣΕ ΤΙΣ ΙΔΙΕΣ):
{tm_snapshot_for_terms_in_this_chunk}

ΚΕΙΜΕΝΟ ΠΡΟΣ ΜΕΤΑΦΡΑΣΗ:
<<<
{chunk_content}
>>>

Δώσε ΜΟΝΟ τη μετάφραση. Καμία επεξήγηση.
```

### 4.6. In-pipeline critique (auto-fix only) — βλ. §2.5

### 4.7. Apply-fixes prompt (παραμένει σχεδόν ίδιο, υπενθυμίζω)

```
Είσαι επιμελητής. Σου δίνω ΠΡΩΤΟΤΥΠΟ, ΜΕΤΑΦΡΑΣΗ, και ΛΙΣΤΑ
ΠΡΟΒΛΗΜΑΤΩΝ.

ΚΑΝΟΝΕΣ:
- Διορθώνεις ΜΟΝΟ τα προβλήματα της λίστας.
- Ότι δεν αναφέρεται, δεν αλλάζει.
- Διατηρείς ακριβώς αριθμό παραγράφων, tags, εισαγωγικά.

ΠΡΟΒΛΗΜΑΤΑ:
{issues_json}

ΠΡΩΤΟΤΥΠΟ:
<<<
{source}
>>>

ΜΕΤΑΦΡΑΣΗ ΠΡΟΣ ΔΙΟΡΘΩΣΗ:
<<<
{translation}
>>>

Δώσε ΜΟΝΟ τη διορθωμένη μετάφραση.
```

### 4.8. Boundary/completeness prompt — βλ. §3.3

### 4.9. Strict audit prompt — βλ. §3.4

### 4.10. Drift sentinel prompt — βλ. §2.6

### 4.11. Polish pass prompt (premium-literary only)

```
Είσαι επιμελητής λογοτεχνικού ύφους. Διαβάζεις ένα ολοκληρωμένο
chunk σε φυσικά ελληνικά και κρίνεις αν, σε σχέση με το πρωτότυπο,
κάποιες παράγραφοι ακούγονται μηχανικές ή αδέξιες — όχι λάθος, αλλά
χωρίς λογοτεχνική αναπνοή.

ΑΥΣΤΗΡΑ:
- Δεν αλλάζεις το νόημα.
- Δεν προτείνεις αλλαγή για παραγράφους που είναι ήδη καλές.
- Επεμβαίνεις ΜΟΝΟ όπου η μετάφραση είναι ξενόφερτη ή αδέξια.
- Διατηρείς ΑΚΡΙΒΩΣ τον αριθμό παραγράφων.
- Διατηρείς ΑΚΡΙΒΩΣ tags [B]/[I]/[U] και εισαγωγικά « ».

Δώσε τη βελτιωμένη εκδοχή ή πανομοιότυπη αν δεν χρειαζόταν αλλαγή.

ΠΡΩΤΟΤΥΠΟ:
<<<
{source}
>>>

ΤΡΕΧΟΥΣΑ ΜΕΤΑΦΡΑΣΗ:
<<<
{translation}
>>>
```

Σημείωση: το polish pass δεν τρέχει για όλα τα chunks. Τρέχει μόνο σε chunks
που το critique τα έχει σημειώσει με confidence != "high" *ή* έχουν >2 hard
passages από το radar.

---

## 5. Συγκεντρωτικά JSON schemas

Όλα έτοιμα να γίνουν Pydantic models στη FastAPI πλευρά.

### 5.1. PrescanResult

```json
{
  "source_language": "string",
  "primary_profile": "literary|academic|legal|theological|historical|journalistic|technical",
  "secondary_profile": "...|null",
  "subject": "string",
  "era_context": "string|null",
  "narrative_tone": "string|null",
  "risk_flags": {
    "has_idioms": "bool",
    "has_archaic_register": "bool",
    "has_cultural_references": "bool",
    "has_wordplay_or_irony": "bool",
    "has_biblical_quotes": "bool",
    "has_legal_terminology": "bool",
    "has_dialects": "bool",
    "has_technical_terminology": "bool"
  },
  "translation_notes": "string",
  "glossary": "[GlossaryEntry, ...]",
  "risk_register": "[RiskRegisterEntry, ...]"
}
```

### 5.2. GlossaryEntry

```json
{
  "id": "uuid",
  "source": "string",
  "target": "string",
  "category": "person|place|org|title|term-technical|term-legal|term-theological|term-historical|recurring-phrase|idiom-translation|fixed-expression",
  "lock": "strict|flexible|transliterate|do_not_translate",
  "frequency": "int",
  "first_occurrence_paragraph": "int|null",
  "examples_of_use": "[string, ...]",
  "alternatives_considered": "[string, ...]",
  "needs_footnote": "bool",
  "translator_note": "string|null"
}
```

### 5.3. RiskRegisterEntry

```json
{
  "id": "uuid",
  "paragraph_index_estimate": "int",
  "source_span": "string",
  "type": "idiom|allusion|wordplay|irony|false_friend|ambiguous_referent|quoted_expression|cultural_reference",
  "gloss": "string",
  "translation_hint": "string",
  "literal_translation_warning": "string|null"
}
```

### 5.4. RadarFinding (per chunk, runtime)

```json
{
  "chunk_index": "int",
  "passages": [
    {
      "source_span": "string",
      "type": "...",
      "gloss": "string",
      "translation_hint": "string"
    }
  ]
}
```

### 5.5. InPipelineCritiqueIssue (auto-fix candidate)

```json
{
  "paragraph_index": "int (1-indexed within chunk)",
  "severity": "critical|major",
  "type": "omission|addition|factual|glossary|formatting|inversion|false_friend",
  "source_span": "string",
  "translated_span": "string|null",
  "suggested_fix": "string",
  "rationale": "string"
}
```

### 5.6. ChunkCritiqueResult

```json
{
  "issues": "[InPipelineCritiqueIssue, ...]",
  "chunk_confidence": "high|medium|low"
}
```

### 5.7. TranslationMemoryEntry

```json
{
  "term_id": "uuid",
  "source_term": "string",
  "category": "string",
  "lock": "string",
  "occurrences": [
    {
      "paragraph": "int",
      "rendering": "string",
      "char_offset_start": "int",
      "char_offset_end": "int"
    }
  ],
  "canonical_target": "string",
  "unique_renderings_normalized": "int",
  "consistency_status": "consistent|inconsistent",
  "expected_inflections": "[string, ...]",
  "anomalous_renderings": [
    {
      "paragraph": "int",
      "rendering": "string"
    }
  ]
}
```

### 5.8. ProgrammaticFinding

```json
{
  "id": "uuid",
  "paragraph_index": "int",
  "type": "missing_number|missing_proper_noun|markup_mismatch|empty_target|length_outlier|quote_mismatch|missing_glossary_term|paragraph_count_mismatch",
  "severity": "critical|major|minor",
  "details": "string",
  "auto_fix_available": "bool",
  "suggested_fix": "string|null"
}
```

### 5.9. BoundaryFinding

```json
{
  "id": "uuid",
  "boundary_type": "doc_start|doc_end|chunk_start|chunk_end",
  "paragraph_index": "int",
  "type": "missing_start|missing_end|missing_sentence|added_sentence",
  "source_span": "string",
  "translated_span": "string|null",
  "missing_content": "string|null",
  "severity": "critical|major"
}
```

### 5.10. AuditSuggestion (final, post-validation)

```json
{
  "id": "uuid",
  "paragraph_index": "int (global, not chunk-local)",
  "chunk_index": "int",
  "category": "mistranslation|inversion|register_shift|consistency|anglicism|mechanical|grammar|punctuation|terminology|terminology_review|completeness|markup",
  "severity": "critical|major|minor",
  "source_span": "string",
  "current_translation": "string",
  "suggested_translation": "string",
  "rationale": "string",
  "confidence": "float",
  "consistency_group": "string|null",
  "auto_applicable": "bool",
  "phase_origin": "programmatic|tm_consistency|boundary_check|llm_audit",
  "validation": {
    "anchor_source": "bool",
    "anchor_target": "bool",
    "not_too_similar": "bool",
    "concrete_rationale": "bool",
    "category_severity_match": "bool",
    "confidence_threshold": "bool",
    "not_glossary_conflict": "bool",
    "not_duplicate": "bool"
  }
}
```

### 5.11. ReviewQueueResponse

```json
{
  "session_id": "string",
  "review_mode": "critical-only|strict|full-strict",
  "stats": {
    "total_paragraphs": "int",
    "paragraphs_with_suggestions": "int",
    "by_severity": {"critical": "int", "major": "int", "minor": "int"},
    "by_category": {"...": "int"},
    "by_phase_origin": {"...": "int"},
    "validation_drop_stats": {
      "kept": "int",
      "dropped_anchor_source": "int",
      "dropped_anchor_target": "int",
      "dropped_too_similar": "int",
      "dropped_generic_rationale": "int",
      "dropped_low_confidence": "int",
      "dropped_per_paragraph_cap": "int",
      "dropped_glossary_conflict": "int",
      "dropped_severity_category_mismatch": "int"
    }
  },
  "suggestions": "[AuditSuggestion, ...] (sorted by severity, then category, then paragraph)",
  "system_warnings": [
    {"type": "drift_detected", "message": "..."}
  ]
}
```

---

## 6. Migration plan

### 6.1. Backward compatibility

Παλιά sessions με glossary entries χωρίς `category`/`lock` πρέπει να
εξακολουθούν να λειτουργούν. Λογική upgrade-on-load:

- Αν entry έχει μόνο `note`, εφαρμόζουμε rules:
  - note ∈ {person, place, org, title, organization} → category αντίστοιχη,
    lock = strict
  - οτιδήποτε άλλο → category=fixed-expression, lock=flexible
- Παλιά chunk_reviews με severity=low → στο audit μετατροπή σε severity=minor
  εφόσον περάσουν validation (αλλιώς dropped).

### 6.2. Feature flags ανά session config

Στο `config.json` προστίθενται:

```json
{
  "translation_mode": "standard|premium-literary|premium-academic|premium-legal|premium-theological|premium-historical",
  "review_mode": "critical-only|strict|full-strict",
  "enable_radar": true,
  "enable_drift_sentinel": true,
  "enable_polish_pass": false,
  "enable_audit_phase": true,
  "validation_thresholds": {
    "min_confidence": 0.7,
    "min_levenshtein_ratio": 0.10,
    "max_per_paragraph": 3
  }
}
```

Έτσι ο audit μπορεί να γίνει on/off, και τα thresholds να tunarιστούν χωρίς
prompt αλλαγές.

### 6.3. Σειρά υλοποίησης (προτεινόμενη)

Δεν χρειάζεται big-bang. Το rollout μπορεί να γίνει σε επτά διακριτά steps,
καθένα έτοιμο να δοκιμαστεί ξεχωριστά:

1. **Step 1 — Glossary v2 schema**: επεκτείνω το prescan Pass A/B να βγάζει
   structured entries. Backward-compat για παλιά sessions. Μόνο schema αλλαγή,
   δεν αλλάζει συμπεριφορά. (Δοκιμή: παλιό session ξεκινά σωστά.)
2. **Step 2 — Profile-driven system prompts**: αντικαθιστά το if/elif. Καμία
   νέα φάση. (Δοκιμή: ίδιο κείμενο, νέο profile, ποιοτική σύγκριση.)
3. **Step 3 — Hard-passage radar**: προαιρετικό βήμα μέσα στο chunk loop. Με
   feature flag ώστε να μπορεί να απενεργοποιηθεί.
4. **Step 4 — Tightened in-pipeline critique**: αλλάζει μόνο το prompt και τα
   `severity` values. Συμβατό με υπάρχον review queue.
5. **Step 5 — Programmatic audit checks**: Phase 4.1 της αρχιτεκτονικής. Καθαρά
   κώδικας, ντετερμινιστικό. Πιο εύκολο για unit tests.
6. **Step 6 — Translation memory + consistency analysis**: Phase 4.2.
7. **Step 7 — LLM strict audit + validation filter + UI**: τελευταίο step,
   χτίζει το νέο review experience πάνω σε όλα τα προηγούμενα.

Κάθε step μπορεί να υπάρξει ως διακριτό PR/release, με δυνατότητα να
απενεργοποιείται μέσω feature flag.

---

## 7. Σημεία προς συζήτηση πριν το coding

Τέσσερα σημεία όπου θέλω input πριν αρχίσω implementation:

1. **Polish pass cost**: σε premium-literary, προσθέτει +1 LLM call ανά chunk
   με confidence != high. Σε ένα μυθιστόρημα 200 σελίδων αυτό μπορεί να
   προσθέσει ~30-50 calls. Είναι αποδεκτό για το premium tier ή θέλεις να μπει
   ως on-demand action μετά το review;
2. **Risk register granularity**: αν το έργο είναι 500 σελίδες, το risk
   register θα γίνει τεράστιο. Να βάλω hard cap (π.χ. top-100 entries ταξινομημένα
   ανά importance) ή να το κρατώ αυτούσιο και να φιλτράρω runtime ανά chunk;
3. **Transliteration για legal/historical**: σε νομικό κείμενο, ονόματα ξένων
   οργανισμών (π.χ. «Internal Revenue Service») τι default κάνεις; Μετάφραση,
   μετεγραφή, ή do_not_translate; Προτείνω: μετάφραση + αρχικό σε παρένθεση
   στην πρώτη εμφάνιση. Συμφωνείς;
4. **Drift sentinel σε non-premium**: αξίζει να τρέχει στο default mode ή το
   κρατάμε αποκλειστικά για premium; Είναι μόλις 1 LLM call ανά 10 chunks,
   πολύ φθηνό.

Όταν συμφωνήσουμε σε αυτά, ξεκινάω από το Step 1.
