# Step 1 — Glossary v2 Schema + Backward Compatibility

## Τι αλλάζει σε αυτό το step

Step 1 εισάγει το structured glossary schema v2 και την backward-compat infrastructure
για να μπορεί το pipeline να δουλεύει με παλιά sessions ή με νέες δομημένες entries
ομοιόμορφα. **Καμία νέα LLM φάση**, **καμία νέα route**. Οι αλλαγές είναι:

1. Νέο module `glossary_v2.py` — schema, upgrade, safe enforcement, formatter.
2. Surgical patches στο `translator.py` — 7 σημεία.
3. Tests που verify ότι τίποτα δεν σπάει για legacy data.

## Τα deliverables

| Αρχείο | Είδος | Σκοπός |
|--------|-------|--------|
| `glossary_v2.py` | **νέο module** | Schema + backward-compat + safe enforcement |
| `test_glossary_v2.py` | unit tests | 23 tests για unit coverage |
| `test_integration_step1.py` | integration tests | Simulates legacy session load |
| `translator_step1.patch` | unified diff | Όλες οι αλλαγές σε `translator.py` |

## Patches στο `translator.py` (αναλυτικά)

### Patch 1 — Import (top of file)

```python
from openai import OpenAI

# Glossary v2 — structured schema with backward compat
import glossary_v2 as _gv2

try:
    import docx
except ImportError:
    docx = None
```

### Patch 2 — `make_system_prompt`: glossary block delegated στο v2 formatter

Παλιά: ~25 γραμμές manual rendering με split για "X/Y" και "X ή Y".
Νέα: μία γραμμή που καλεί `_gv2.format_glossary_for_prompt(glossary)`.

Το νέο rendering ομαδοποιεί ανά κατηγορία (πρόσωπα, τόποι, οργανισμοί κ.λπ.)
και γράφει σαφώς τι σημαίνει κάθε lock state ώστε ο μεταφραστής να ξέρει
(π.χ. `lock=do_not_translate` → εμφανίζεται ως «ΔΙΑΤΗΡΗΣΕ ΩΣ ΕΧΕΙ»).

### Patch 3 — `make_prescan_prompt`: ζητάει v2 schema

Το JSON schema που ζητάει η Pass A έχει αλλάξει από:

```json
{"source": "...", "target": "...", "note": "person/place/org/title/term"}
```

σε:

```json
{
  "source": "...",
  "target": "... (μία απόδοση μόνο)",
  "category": "person|place|org|...|fixed-expression",
  "lock": "strict|flexible|transliterate|do_not_translate",
  "needs_footnote": false
}
```

με αναλυτικές οδηγίες πότε να βάζει κάθε category και κάθε lock value.

### Patch 4 — Pass B (terminology sweep) prompt

Ίδια αλλαγή με την Pass A αλλά για το dedicated terminology extraction
prompt μέσα στο `prescan()`.

### Patch 5 — Prescan merge logic

Παλιά: manual deduplication με `seen` set + literary filter με βάση `note`.

Νέα:
```python
merged = _gv2.upgrade_glossary_list(
    list(initial_glossary) + list(extracted_terms)
)
```

Το `upgrade_glossary_list` κάνει αναβάθμιση σε v2 schema + dedup ταυτόχρονα.

Ο literary-mode filter παραμένει αλλά τώρα χρησιμοποιεί `category`
(`{"person", "place", "org", "title"}`) αντί για `note`. Αυτό διατηρεί τη
συμπεριφορά στις παλιές περιπτώσεις και ταυτόχρονα δουλεύει σωστά για τις νέες.

> **Σημείωση**: το literary-mode filter είναι πλέον λογικά πλεονάζον γιατί η
> νέα `enforce_glossary_v2` ήδη σκιπάρει `lock != strict`. Παρόλα αυτά το
> κρατάμε για Step 1 ώστε να μην αλλάξει η συμπεριφορά. Σε επόμενο step θα
> αφαιρεθεί.

### Patch 6 — `enforce_glossary` thin wrapper

Παλιά: 60+ γραμμές find-replace logic με δικά της edge cases.
Νέα: 30 γραμμές wrapper που:

1. Αναβαθμίζει legacy entries inline αν χρειαστεί (defensive)
2. Καλεί `_gv2.enforce_glossary_v2()`
3. Εκτυπώνει stats με νέα format (case-norms, alt-collapses, skipped-inflection-safe)

Το πραγματικό logic είναι στο `glossary_v2.py` με τους εξής safety checks:

- **Lock filter**: μόνο `lock == "strict"` entries υφίστανται find-replace.
- **Inflection safety**: αν ο match περιστοιχίζεται από Greek letters σε
  οποιαδήποτε πλευρά, παραλείπεται. Δηλαδή `target="Λονδίνο"` δεν θα
  διορθώσει το match μέσα στο «Λονδίνου» (γενική).
- **Alternatives collapse**: αν ο LLM γράψει «Λονδίνο ή Λοντίνο»,
  ενοποιείται στο canonical target.

### Patch 7 — `load_progress`: upgrade legacy glossary on load

```python
self.glossary = data.get("glossary", [])
if self.glossary:
    upgraded = _gv2.upgrade_glossary_list(self.glossary)
    # ... log αν έγινε αλλαγή ...
    self.glossary = upgraded
```

Παλιές sessions ξυπνούν με σωστό v2 schema χωρίς manual μετανάστευση δεδομένων.

## Τι δεν αλλάζει

- Ο αριθμός των LLM calls στο pipeline (ίδιος).
- Η ροή translate → critique → apply-fixes (ίδια).
- Το API surface (ίδιο — endpoints αναλλοίωτα).
- Οι παλιές παράμετροι του `make_system_prompt` (signature ίδιο).
- Τα `chunk_reviews` (ίδιο schema).
- Το frontend (`page.js`) δεν χρειάζεται καμία αλλαγή.

## Verification

`test_glossary_v2.py`: 23 unit tests, όλα passing:
- 10 upgrade tests (legacy → v2, idempotency, dedup, invalid handling)
- 7 enforcement tests (κρίσιμο: inflection safety δοκιμασμένο)
- 4 prompt formatting tests
- 1 diagnostic test
- 1 integration test με συνθετικό dataset

`test_integration_step1.py`: 6 integration tests:
- Legacy session load + auto-upgrade
- enforce_glossary με upgraded entries
- enforce_glossary με raw legacy (auto-upgrades inline)
- make_system_prompt με v2 formatter
- make_system_prompt defensive με legacy
- make_prescan_prompt περιέχει v2 schema fields

## Πώς το εφαρμόζεις

1. Βάλε το `glossary_v2.py` στον φάκελο όπου είναι ο `translator.py`.
2. Εφάρμοσε το `translator_step1.patch`:
   ```bash
   patch -p0 < translator_step1.patch
   ```
   ή χειροκίνητα τα 7 σημεία (όλα σαφώς οριοθετημένα στο diff).
3. Τρέξε τα tests:
   ```bash
   python test_glossary_v2.py
   python test_integration_step1.py
   ```
4. Δοκίμασε σε μια νέα session να δεις ότι το prescan output έχει
   `category`/`lock` σωστά συμπληρωμένα.
5. Δοκίμασε σε μια παλιά session (αν υπάρχει στο `translation_sessions/`)
   να δεις ότι ξυπνάει σωστά και η enforcement δουλεύει.

## Επόμενο step

**Step 2 — Profile-driven system prompts.** Αντικαθιστά τη δομή
`if literary elif theological…` μέσα στο `make_system_prompt` με έξι αυτόνομα
profile blocks (literary, academic, legal, theological, historical,
journalistic) και έναν blender για mixed περιπτώσεις. Επίσης προσθέτει
`primary_profile`/`secondary_profile` στο prescan output.

Καμία νέα LLM call προστίθεται — αλλάζει μόνο το πώς συντίθεται το system
prompt. Το αποτέλεσμα είναι σαφώς διαφορετικός μεταφραστικός τόνος ανά profile,
χωρίς να χάνεται η σαφήνεια της προηγούμενης λογικής.
