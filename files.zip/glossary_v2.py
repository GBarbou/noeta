"""
ProofreadAI Glossary v2
=======================
Structured glossary schema with backward compatibility.

Design goals:
  - Διάκριση proper nouns από common terms μέσω `category`.
  - Έλεγχος αν ένας όρος επιβάλλεται blindly μέσω `lock`.
  - Ασφαλές post-processing: ποτέ δεν χαλάμε κλιτές μορφές, σύνταξη ή
    συμφραζόμενο.
  - Backward compat: παλιές entries (legacy: only `note` field) αναβαθμίζονται
    αυτόματα κατά το load με sensible defaults.

Categories:
    person, place, org, title,
    term-technical, term-legal, term-theological, term-historical,
    recurring-phrase, idiom-translation, fixed-expression

Locks:
    strict           → πάντα ίδια απόδοση. Find-replace ενεργό (με safety).
    flexible         → ίδια απόδοση αλλά επιτρέπεται κλίση. Find-replace OFF.
    transliterate    → μετάγραψε, μη μεταφράζεις. Find-replace OFF.
    do_not_translate → άφησε ως έχει στη γλώσσα πηγής. Find-replace OFF.
"""

from __future__ import annotations
import re
import uuid
from typing import List, Dict, Optional, Tuple, Any


# ============== CONSTANTS ==============

CATEGORIES = (
    "person",
    "place",
    "org",
    "title",
    "term-technical",
    "term-legal",
    "term-theological",
    "term-historical",
    "recurring-phrase",
    "idiom-translation",
    "fixed-expression",
)

LOCKS = ("strict", "flexible", "transliterate", "do_not_translate")

# Mapping από παλιά "note" string σε category v2.
# Tolerant: lowercase, punctuation-stripped, plurals/synonyms.
LEGACY_NOTE_TO_CATEGORY: Dict[str, str] = {
    "person":           "person",
    "people":           "person",
    "human":            "person",
    "name":             "person",
    "character":        "person",
    "place":            "place",
    "location":         "place",
    "city":             "place",
    "country":          "place",
    "toponym":          "place",
    "geographic":       "place",
    "org":              "org",
    "organization":     "org",
    "organisation":     "org",
    "company":          "org",
    "institution":      "org",
    "agency":           "org",
    "title":            "title",
    "book":             "title",
    "song":             "title",
    "movie":            "title",
    "film":             "title",
    "newspaper":        "title",
    "term":             "fixed-expression",
    "technical":        "term-technical",
    "tech":             "term-technical",
    "legal":            "term-legal",
    "law":              "term-legal",
    "theological":      "term-theological",
    "theology":         "term-theological",
    "ecclesiastical":   "term-theological",
    "historical":       "term-historical",
    "history":          "term-historical",
    "phrase":           "recurring-phrase",
    "expression":       "fixed-expression",
    "idiom":            "idiom-translation",
}

# Default lock ανά category — επιλέγεται για να μην χαλάει η κλίση
# σε κείμενα όπου common terms εμφανίζονται σε πολλές πτώσεις.
DEFAULT_LOCK_BY_CATEGORY: Dict[str, str] = {
    "person":              "strict",
    "place":               "strict",
    "org":                 "strict",
    "title":               "strict",
    "term-technical":      "flexible",
    "term-legal":          "strict",
    "term-theological":    "strict",
    "term-historical":     "flexible",
    "recurring-phrase":    "flexible",
    "idiom-translation":   "flexible",
    "fixed-expression":    "strict",
}

# Greek alphabet (πεζά + κεφαλαία + τονούμενα) — για word-boundary detection.
GR_LETTER_CLASS = (
    "α-ωΑ-ΩάέήίόύώϊϋΐΰΆΈΉΊΌΎΏΪΫϊϋ"
)
_RE_GR_LETTER = re.compile(f"[{GR_LETTER_CLASS}]")


# ============== ENTRY OPERATIONS ==============

def make_entry_id() -> str:
    """Σύντομο unique id για glossary entry."""
    return str(uuid.uuid4())[:12]


def _normalize_note_token(raw_note: str) -> Optional[str]:
    """
    Παίρνει legacy note string (μπορεί να είναι "person", "place/term",
    "person, location") και επιστρέφει το πρώτο γνωστό category.
    """
    if not raw_note:
        return None
    cleaned = raw_note.strip().lower()
    # Σπάμε σε tokens με κοινούς διαχωριστές
    tokens = re.split(r"[/,;|\s]+", cleaned)
    for tok in tokens:
        tok = tok.strip(".:-_()[]")
        if not tok:
            continue
        if tok in LEGACY_NOTE_TO_CATEGORY:
            return LEGACY_NOTE_TO_CATEGORY[tok]
    return None


def _split_legacy_alternatives(target: str) -> Tuple[str, List[str]]:
    """
    Σε legacy entries η απόδοση μπορεί να είχε 'X/Y' ή 'X ή Y'.
    Επιστρέφουμε canonical_target + alternatives list.
    """
    target = (target or "").strip()
    if not target:
        return "", []
    # Έλεγχος για ' ή '
    if " ή " in target:
        parts = [p.strip() for p in target.split(" ή ") if p.strip()]
        if len(parts) >= 2:
            return parts[0], parts[1:]
    # Έλεγχος για '/'
    if "/" in target:
        parts = [p.strip() for p in target.split("/") if p.strip()]
        if len(parts) >= 2:
            return parts[0], parts[1:]
    return target, []


def upgrade_legacy_entry(entry: Any) -> Optional[Dict]:
    """
    Μετατρέπει legacy entry → v2 entry.

    Legacy schema:  {"source": "...", "target": "...", "note": "..."}
    V2 schema:      πλήρης δομή με id/category/lock/etc.

    Idempotent: αν το entry είναι ήδη v2, συμπληρώνει τυχόν missing fields
    χωρίς να αλλάζει υπάρχοντα.

    Returns None αν το entry είναι invalid (λείπει source ή target).
    """
    if not isinstance(entry, dict):
        return None

    source = (entry.get("source") or "").strip()
    target_raw = (entry.get("target") or "").strip()
    if not source or not target_raw:
        return None

    # Already v2?
    has_category = "category" in entry and entry.get("category")
    has_lock = "lock" in entry and entry.get("lock")
    is_v2 = bool(has_category and has_lock)

    if is_v2:
        # Συμπλήρωση missing optional fields, χωρίς override υπαρχόντων.
        upgraded = dict(entry)
        upgraded.setdefault("id", make_entry_id())
        upgraded.setdefault("frequency", 0)
        upgraded.setdefault("first_occurrence_paragraph", None)
        upgraded.setdefault("examples_of_use", [])
        upgraded.setdefault("alternatives_considered", [])
        upgraded.setdefault("needs_footnote", False)
        upgraded.setdefault("translator_note", None)

        # Validate enums και κάνε fallback
        if upgraded["category"] not in CATEGORIES:
            upgraded["category"] = "fixed-expression"
        if upgraded["lock"] not in LOCKS:
            upgraded["lock"] = DEFAULT_LOCK_BY_CATEGORY.get(
                upgraded["category"], "flexible"
            )
        return upgraded

    # Legacy upgrade path
    legacy_note = (entry.get("note") or "").strip()
    category = _normalize_note_token(legacy_note) or "fixed-expression"
    lock = DEFAULT_LOCK_BY_CATEGORY.get(category, "flexible")

    canonical, alternatives = _split_legacy_alternatives(target_raw)

    return {
        "id": make_entry_id(),
        "source": source,
        "target": canonical,
        "category": category,
        "lock": lock,
        "frequency": 0,
        "first_occurrence_paragraph": None,
        "examples_of_use": [],
        "alternatives_considered": alternatives,
        "needs_footnote": False,
        "translator_note": None,
        # Διαγνωστικά για το παλιό note (δεν χρησιμοποιείται από κανέναν consumer,
        # απλώς επιτρέπει debugging αργότερα)
        "_legacy_note": legacy_note or None,
    }


def upgrade_glossary_list(glossary: Optional[List[Dict]]) -> List[Dict]:
    """
    Αναβαθμίζει ολόκληρη λίστα. Αφαιρεί διπλότυπα με βάση (source, target)
    case-insensitive.
    """
    if not glossary:
        return []

    upgraded: List[Dict] = []
    seen: set = set()
    for entry in glossary:
        new_entry = upgrade_legacy_entry(entry)
        if not new_entry:
            continue
        key = (new_entry["source"].lower().strip(),
               new_entry["target"].lower().strip())
        if key in seen:
            continue
        seen.add(key)
        upgraded.append(new_entry)
    return upgraded


def normalize_prescan_glossary(prescan_entries: Optional[List[Dict]]) -> List[Dict]:
    """
    Public API for prescan output: τα LLM responses μπορεί να βγάζουν
    ανακριβή schemas. Κανονικοποιούμε σε v2.
    """
    return upgrade_glossary_list(prescan_entries or [])


# ============== ENFORCEMENT (POST-PROCESSING) ==============

def _is_part_of_longer_greek_word(text: str, start: int, end: int) -> bool:
    """
    Επιστρέφει True αν ο match περιστοιχίζεται από Greek letters σε οποιαδήποτε
    πλευρά. Σημαίνει ότι είναι substring κλιτής μορφής ή σύνθετης λέξης —
    και αν αντικαταστήσουμε, χαλάμε τη λέξη.
    """
    # char πριν τον match
    if start > 0:
        prev_char = text[start - 1]
        if _RE_GR_LETTER.match(prev_char):
            return True
    # char μετά τον match
    if end < len(text):
        next_char = text[end]
        if _RE_GR_LETTER.match(next_char):
            return True
    return False


def enforce_glossary_v2(
    translated_texts: List[str],
    glossary: List[Dict],
) -> Tuple[List[str], Dict]:
    """
    Cautious find-replace enforcement.

    Operates ΜΟΝΟ σε entries με `lock == "strict"`.
    Παραλείπει replacements που θα έσπαγαν κλιτές/σύνθετες μορφές.

    Returns:
        (updated_texts, stats_dict)

    Stats fields:
        replacements_made           — case normalizations εφαρμοσμένα
        alternative_collapses       — patterns "X ή Y" που ενοποιήθηκαν
        skipped_inflection_risk     — πόσες αντικαταστάσεις απορρίφθηκαν
                                      γιατί θα έσπαγαν κλιτή
        skipped_locks               — count ανά lock value που παραλείφθηκε
        entries_processed           — strict entries που εφαρμόστηκαν
    """
    stats: Dict[str, Any] = {
        "replacements_made": 0,
        "alternative_collapses": 0,
        "skipped_inflection_risk": 0,
        "skipped_locks": {"flexible": 0, "transliterate": 0, "do_not_translate": 0},
        "entries_processed": 0,
    }

    if not glossary:
        return list(translated_texts), stats

    result = list(translated_texts)

    for entry in glossary:
        if not isinstance(entry, dict):
            continue

        lock = entry.get("lock", "strict")
        if lock != "strict":
            stats["skipped_locks"][lock] = stats["skipped_locks"].get(lock, 0) + 1
            continue

        target = (entry.get("target") or "").strip()
        source = (entry.get("source") or "").strip()
        if not target or not source:
            continue

        stats["entries_processed"] += 1

        # alternatives_considered + canonical target — χρησιμοποιούνται για να
        # ενοποιήσουμε "X ή Y" patterns που μπορεί να βγάζει ο LLM.
        alts = entry.get("alternatives_considered") or []
        if not isinstance(alts, list):
            alts = []
        all_renderings = [target] + [a for a in alts if a and a != target]

        for i, text in enumerate(result):
            if not text:
                continue

            # ----- Step 1: ενοποίηση "X ή Y" patterns -----
            if len(all_renderings) >= 2:
                for j in range(len(all_renderings)):
                    for k in range(len(all_renderings)):
                        if j == k:
                            continue
                        for sep in (" ή ", "/"):
                            wrong_pattern = f"{all_renderings[j]}{sep}{all_renderings[k]}"
                            if wrong_pattern in text:
                                text = text.replace(wrong_pattern, target)
                                stats["alternative_collapses"] += 1

            # ----- Step 2: case normalization, με safety check -----
            # Αναζητούμε mismatched casings του target (π.χ. "λονδίνο" → "Λονδίνο")
            # αλλά ΜΟΝΟ όπου ο match δεν είναι μέρος μεγαλύτερης ελληνικής λέξης.
            #
            # Σειρά ελέγχων (κρίσιμη):
            #   1. inflection check ΠΡΩΤΑ — αν ο match είναι substring κλιτής
            #      μορφής, παραλείπουμε και μετράμε, ανεξάρτητα από casing.
            #   2. μετά casing check — αν ίδια casing, καμία ενέργεια.
            #   3. αλλιώς, safe replacement.
            pattern = re.compile(re.escape(target), re.IGNORECASE)
            chunks: List[str] = []
            last_end = 0
            for match in pattern.finditer(text):
                ms, me = match.span()
                found = match.group()

                if _is_part_of_longer_greek_word(text, ms, me):
                    # κίνδυνος να σπάσουμε κλιτή/σύνθετη μορφή
                    stats["skipped_inflection_risk"] += 1
                    continue

                if found == target:
                    # ήδη σωστή casing και standalone word → καμία ενέργεια
                    continue

                # safe replacement
                chunks.append(text[last_end:ms])
                chunks.append(target)
                last_end = me
                stats["replacements_made"] += 1
            chunks.append(text[last_end:])
            text = "".join(chunks)

            result[i] = text

    return result, stats


# ============== PROMPT FORMATTING ==============

# Σύντομα labels για κάθε lock state, που μπαίνουν στο system prompt
# ώστε ο μεταφραστής να ξέρει πώς να τα χειριστεί.
_LOCK_PROMPT_LABEL: Dict[str, str] = {
    "strict":           "πάντα ίδια απόδοση",
    "flexible":         "ίδια απόδοση, επιτρέπεται κλίση",
    "transliterate":    "μετάγραψε, ΜΗΝ μεταφράζεις",
    "do_not_translate": "ΜΗΝ μεταφράζεις — διατήρησε ακριβώς ως έχει",
}

# Friendly Greek labels για category (μόνο για prompt readability)
_CATEGORY_PROMPT_LABEL: Dict[str, str] = {
    "person":              "πρόσωπο",
    "place":               "τόπος",
    "org":                 "οργανισμός",
    "title":               "τίτλος",
    "term-technical":      "τεχνικός όρος",
    "term-legal":          "νομικός όρος",
    "term-theological":    "θεολογικός όρος",
    "term-historical":     "ιστορικός όρος",
    "recurring-phrase":    "επαναλαμβανόμενη φράση",
    "idiom-translation":   "ιδιωματική απόδοση",
    "fixed-expression":    "πάγια έκφραση",
}


def format_glossary_for_prompt(glossary: List[Dict]) -> str:
    """
    Παράγει το glossary block για το translation system prompt.

    Differences από v1:
      - Δείχνει category και lock label
      - Για lock=do_not_translate δεν εμφανίζεται καν target — υπενθύμιση
        μόνο ότι ο όρος μένει ως έχει
      - Ομαδοποιεί entries ανά κατηγορία ώστε ο μεταφραστής να βλέπει
        τη δομή

    Empty glossary → empty string.
    """
    if not glossary:
        return ""

    # Group by category, διατηρώντας τη σειρά εμφάνισης ανά κατηγορία.
    by_cat: Dict[str, List[Dict]] = {}
    cat_order: List[str] = []
    for entry in glossary:
        cat = entry.get("category", "fixed-expression")
        if cat not in by_cat:
            by_cat[cat] = []
            cat_order.append(cat)
        by_cat[cat].append(entry)

    # Display order: proper nouns πρώτα, μετά τεχνικοί όροι, τέλος γενικοί.
    preferred_order = [
        "person", "place", "org", "title",
        "term-legal", "term-theological", "term-historical", "term-technical",
        "fixed-expression", "recurring-phrase", "idiom-translation",
    ]
    sorted_cats = (
        [c for c in preferred_order if c in by_cat] +
        [c for c in cat_order if c not in preferred_order]
    )

    lines: List[str] = []
    lines.append("\n\nΥΠΟΧΡΕΩΤΙΚΟ ΓΛΩΣΣΑΡΙ "
                 "(χρησιμοποίησε ΑΚΡΙΒΩΣ αυτές τις αποδόσεις, "
                 "μία απόδοση ανά όρο, ΟΧΙ εναλλακτικές με «ή» ή «/»):")

    for cat in sorted_cats:
        cat_label = _CATEGORY_PROMPT_LABEL.get(cat, cat)
        lines.append(f"\n[{cat_label}]")
        for entry in by_cat[cat]:
            src = entry.get("source", "")
            tgt = entry.get("target", "")
            lock = entry.get("lock", "strict")
            note = entry.get("translator_note") or ""
            footnote = entry.get("needs_footnote", False)

            lock_label = _LOCK_PROMPT_LABEL.get(lock, "")

            if lock == "do_not_translate":
                line = f"  • {src} → ΔΙΑΤΗΡΗΣΕ ΩΣ ΕΧΕΙ ({lock_label})"
            elif lock == "transliterate":
                line = f"  • {src} → {tgt} ({lock_label})"
            else:
                line = f"  • {src} → {tgt}"
                if lock_label and lock != "strict":
                    # Για strict δεν χρειάζεται extra info, για flexible αξίζει
                    line += f"  ({lock_label})"

            if footnote:
                line += "  [χρειάζεται υποσημείωση]"
            if note:
                line += f"  — {note}"

            lines.append(line)

    return "\n".join(lines)


# ============== DIAGNOSTICS ==============

def glossary_summary(glossary: List[Dict]) -> Dict[str, Any]:
    """Σύντομη στατιστική για logging/debugging."""
    if not glossary:
        return {
            "total": 0,
            "by_category": {},
            "by_lock": {},
            "needs_footnote": 0,
        }
    by_cat: Dict[str, int] = {}
    by_lock: Dict[str, int] = {}
    needs_footnote = 0
    for e in glossary:
        c = e.get("category", "?")
        l = e.get("lock", "?")
        by_cat[c] = by_cat.get(c, 0) + 1
        by_lock[l] = by_lock.get(l, 0) + 1
        if e.get("needs_footnote"):
            needs_footnote += 1
    return {
        "total": len(glossary),
        "by_category": by_cat,
        "by_lock": by_lock,
        "needs_footnote": needs_footnote,
    }
