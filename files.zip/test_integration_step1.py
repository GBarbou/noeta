"""
Integration test: simulate loading a legacy progress.json from an old session.

Tests that:
  1. Legacy glossary upgrades cleanly on load_progress
  2. enforce_glossary (now v2 wrapper) handles upgraded entries correctly
  3. format_glossary_for_prompt produces sensible output for upgraded entries
"""

import sys
import os
import json
import tempfile
import shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Stub out openai/docx imports so we can import translator without deps
class _OpenAIStub:
    def __init__(self, *args, **kwargs): pass
sys.modules['openai'] = type(sys)('openai')
sys.modules['openai'].OpenAI = _OpenAIStub

import translator
import glossary_v2 as g2


def test_load_legacy_session():
    """Simulate κατάσταση: παλιά session με legacy glossary entries → load."""
    tmpdir = tempfile.mkdtemp()
    try:
        # Δημιουργούμε legacy progress.json όπως θα ήταν από παλιά version
        session_id = "legacy_test"
        sess_dir = os.path.join(tmpdir, session_id)
        os.makedirs(sess_dir)

        # Override TRANSLATION_DIR για το test
        import pathlib
        translator.TRANSLATION_DIR = pathlib.Path(tmpdir)

        legacy_progress = {
            "status": "ready",
            "progress": 5,
            "total_chunks": 5,
            "source_language": "English",
            "document_brief": "Τύπος: novel\nΘέμα: Victorian London",
            "style_register": "λογοτεχνικό",
            "glossary": [
                # Legacy entries — μόνο source/target/note
                {"source": "London", "target": "Λονδίνο", "note": "place"},
                {"source": "John Smith", "target": "Τζον Σμιθ", "note": "person"},
                {"source": "BBC", "target": "BBC", "note": "organization"},
                {"source": "data", "target": "δεδομένα", "note": "term"},
                # Παλιό "X/Y" pattern
                {"source": "monastery", "target": "μοναστήρι/μονή", "note": "term"},
            ],
            "translated": ["Παράγραφος 1.", "Παράγραφος 2.", "", "", ""],
            "filename": "test.docx",
            "is_docx": True,
            "error_message": "",
            "chunk_reviews": [],
        }

        progress_path = os.path.join(sess_dir, "progress.json")
        with open(progress_path, "w", encoding="utf-8") as f:
            json.dump(legacy_progress, f, ensure_ascii=False)

        # Τώρα δοκιμάζουμε load
        session = translator.TranslationSession(session_id)
        loaded = session.load_progress()
        assert loaded, "load_progress πρέπει να επιστρέψει True"

        # Verify upgrade
        assert all("category" in e for e in session.glossary), \
            "Όλες οι entries πρέπει να έχουν category μετά το upgrade"
        assert all("lock" in e for e in session.glossary), \
            "Όλες οι entries πρέπει να έχουν lock"

        # Verify category mapping
        cats_by_src = {e["source"]: e["category"] for e in session.glossary}
        assert cats_by_src["London"] == "place"
        assert cats_by_src["John Smith"] == "person"
        assert cats_by_src["BBC"] == "org"
        assert cats_by_src["data"] == "fixed-expression"
        assert cats_by_src["monastery"] == "fixed-expression"

        # Verify monastery alternatives split
        monastery = next(e for e in session.glossary if e["source"] == "monastery")
        assert monastery["target"] == "μοναστήρι"
        assert monastery["alternatives_considered"] == ["μονή"]

        print("  ✓ test_load_legacy_session — legacy entries upgraded correctly")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def test_enforce_glossary_with_upgraded_entries():
    """enforce_glossary (το patched wrapper) πρέπει να δουλεύει με upgraded entries."""
    upgraded_glossary = g2.upgrade_glossary_list([
        {"source": "London", "target": "Λονδίνο", "note": "place"},
    ])
    texts = [
        "Πήγε στο λονδίνο.",
        "Έφυγε από το Λονδίνου με τρένο.",  # γενική — να μην σπάσει
    ]
    result = translator.enforce_glossary(texts, upgraded_glossary)
    assert result[0] == "Πήγε στο Λονδίνο."  # case normalized
    assert result[1] == texts[1]  # genitive preserved
    print("  ✓ test_enforce_glossary_with_upgraded_entries")


def test_enforce_glossary_with_legacy_entries_inline():
    """
    enforce_glossary δέχεται και legacy entries χωρίς upgrade —
    auto-upgrades inline (backward compat).
    """
    legacy_glossary = [
        {"source": "London", "target": "Λονδίνο", "note": "place"},
    ]
    texts = ["Πήγε στο λονδίνο."]
    result = translator.enforce_glossary(texts, legacy_glossary)
    assert result[0] == "Πήγε στο Λονδίνο."
    print("  ✓ test_enforce_glossary_with_legacy_entries_inline")


def test_make_system_prompt_uses_v2_formatter():
    """make_system_prompt χρησιμοποιεί τον v2 formatter."""
    glossary = g2.upgrade_glossary_list([
        {"source": "London", "target": "Λονδίνο", "note": "place"},
        {"source": "John", "target": "Τζον", "note": "person"},
    ])
    prompt = translator.make_system_prompt(
        source_language="English",
        document_brief="A novel.",
        glossary=glossary,
        style_register="λογοτεχνικό",
    )
    # Έλεγχος ότι το v2 format εμφανίζεται με category labels
    assert "[τόπος]" in prompt
    assert "[πρόσωπο]" in prompt
    assert "Λονδίνο" in prompt
    assert "Τζον" in prompt
    # Δεν έχει το παλιό inline note format
    assert "(person)" not in prompt
    assert "(place)" not in prompt
    print("  ✓ test_make_system_prompt_uses_v2_formatter")


def test_make_system_prompt_with_legacy_glossary_works():
    """Defensive: αν κάποιος καλέσει με legacy entries, να μη σκάει."""
    # Τα legacy entries δεν θα είχαν category/lock, αλλά ο formatter πρέπει
    # να ανέχεται και να τα δείχνει σε default group.
    # Όμως: ο formatter δεν κάνει inline upgrade, οπότε ο caller πρέπει να
    # έχει κάνει upgrade πριν. Στο pipeline μας αυτό συμβαίνει.
    # Test ότι τουλάχιστον δεν crash-άρει.
    legacy_glossary = [
        {"source": "London", "target": "Λονδίνο", "note": "place"},
    ]
    # Legacy entries χωρίς category/lock δίνουν invalid v2 format,
    # αλλά ο formatter δεν πρέπει να σκάσει — απλώς δεν θα τα ομαδοποιήσει
    # σωστά. Στην πράξη αυτό δεν θα συμβεί γιατί κάνουμε upgrade πιο πάνω.
    try:
        prompt = translator.make_system_prompt(
            source_language="English",
            document_brief="A novel.",
            glossary=legacy_glossary,
            style_register="λογοτεχνικό",
        )
        # Αν περάσει χωρίς exception, OK.
        print("  ✓ test_make_system_prompt_with_legacy_glossary_works")
    except Exception as e:
        raise AssertionError(f"make_system_prompt crashed on legacy entries: {e}")


def test_make_prescan_prompt_v2_schema():
    """Το νέο prescan prompt ζητάει category και lock."""
    p = translator.make_prescan_prompt("Some text")
    assert "category" in p
    assert "lock" in p
    assert "strict" in p
    assert "flexible" in p
    assert "transliterate" in p
    assert "do_not_translate" in p
    # Δεν περιέχει το παλιό schema
    assert '"note": "person/place/org/title/term"' not in p
    print("  ✓ test_make_prescan_prompt_v2_schema")


if __name__ == "__main__":
    print("Running integration tests with patched translator.py...\n")
    test_load_legacy_session()
    test_enforce_glossary_with_upgraded_entries()
    test_enforce_glossary_with_legacy_entries_inline()
    test_make_system_prompt_uses_v2_formatter()
    test_make_system_prompt_with_legacy_glossary_works()
    test_make_prescan_prompt_v2_schema()
    print("\n✓ All integration tests passed.")
