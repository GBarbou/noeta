# ProofreadAI Translation v2 — Implementation Brief for Claude Code

> **For the agent reading this file**: this document is your starting context.
> Read it fully before touching any code. The full architecture spec is in
> `proofreadai_translation_v2_architecture.md` (same folder). Per-step
> instructions live in this file (§7). Decisions already made by the project
> owner live in §6.

---

## 1. What is ProofreadAI

ProofreadAI is a publishing-grade tool with two main modules:

1. **Greek text proofreading editor** — TipTap-based editor with LLM-driven
   diff suggestions. Out of scope for this project.
2. **Literary translation engine** — what you'll be working on.

The translation engine takes a source-language manuscript (typically English,
sometimes French/Russian/Ancient Greek/Katharevousa) and produces a Modern
Greek translation suitable for book publication. Target output quality is
**editorial**, not just "good enough" — these translations get used in
actual published books.

The owner (George Barbounakis) runs **Εκδόσεις Μπαρμπουνάκης**, a publishing
house in Thessaloniki. He uses ProofreadAI on his own catalog. The tool is
also a commercial asset he's developing.

## 2. Tech stack

```
Frontend:  Next.js (React)              — page.js for the translation UI
Backend:   FastAPI (Python)             — main.py as the API entry point
LLM:       OpenRouter API               — Gemini 3 family is the default
Storage:   Filesystem (JSON progress)   — translation_sessions/{session_id}/
```

Other things you'll see in the codebase:

- `paraphraser.py` — separate paraphrasing module, do not touch.
- `glossary_v2.py` — **NEW** module from Step 1 (already in the repo or being
  added with this PR).
- `track_changes.py`, `editor.py`, etc. — proofreader module, do not touch.

## 3. Coding conventions in this project

- **All user-facing strings in Greek.** That includes prompts (which are sent
  to the LLM and influence output language), error messages, and log lines
  that the owner reads. Code identifiers and code comments may be in English.
- **Greek code comments are common and welcomed**, especially for design
  rationale.
- **No new dependencies without justification.** stdlib + the existing
  `openai` SDK should cover everything in this project.
- **Async/await throughout the API and pipeline.** LLM calls go through
  `asyncio.to_thread`.
- **Crash-safety matters.** The translation pipeline runs for hours on long
  books. Always save progress after each chunk; always make resume idempotent.
- **Glossary entries are v2 schema** (see §4). Do not regress to legacy.

## 4. Architecture documents

Three reference files live in this folder. **Read them in this order:**

| File | What it gives you |
|------|-------------------|
| `proofreadai_translation_v2_architecture.md` | The full design spec. All prompts, all schemas, all pipeline stages. |
| `STEP1_PATCH_SUMMARY.md` | What Step 1 changed and why. |
| `CLAUDE_CODE_BRIEF.md` | This file — the actionable roadmap. |

Whenever this brief points to "§X.Y of the architecture spec", that means
the corresponding section of `proofreadai_translation_v2_architecture.md`.
The brief is the work plan; the spec is the source of truth for prompts and
schemas.

## 5. Current state

**Step 1 is complete** as a deliverable but **may or may not be merged into
the codebase yet**. Check whether `glossary_v2.py` exists and whether
`translator.py` has the import line `import glossary_v2 as _gv2`. If not,
your first task is to apply Step 1 (see §7.1 for instructions).

Step 1 deliverables that already exist as files:

```
glossary_v2.py              # the new module
test_glossary_v2.py         # 23 unit tests (all passing as of handoff)
test_integration_step1.py   # 6 integration tests (all passing)
translator_step1.patch      # unified diff for translator.py
translator_patched.py       # reference: what translator.py looks like patched
```

Steps 2–7 are NOT implemented yet. They are described in §7 of this brief
plus the architecture spec.

## 6. Decisions already made (do not relitigate)

These were resolved in design discussions with the owner. Treat them as
fixed constraints.

1. **Polish pass is on-demand only.** Never run automatically. Implemented
   as a manual UI action (`polish selected` / `polish flagged chunks`) that
   the user triggers after translation completes. Don't add polish calls to
   the chunk loop.

2. **Risk register cap: 100–150 entries.** For long books, sort by
   importance (frequency × estimated difficulty) and keep top-N. Runtime
   hard-passage radar covers anything that didn't make the cut.

3. **Foreign organizations and proper nouns in legal/historical mode**:
   - If a paganized Greek form exists, use it.
   - If not, render in Greek + put the original in parentheses on first
     occurrence ("Internal Revenue Service (IRS)" → "Υπηρεσία Δημόσιων
     Εσόδων (Internal Revenue Service)").
   - For names without paganized form, use **consistent transliteration**.
   - For laws/organizations functioning as official names, **never invent**
     a translation without including the original.

4. **Drift sentinel runs in all modes** (default + premium), but emits
   only a `system_warning` flag — never auto-corrects. If profiling shows
   it adds significant latency in default mode, restrict to premium.

5. **Glossary find-replace is intentionally limited.** Only `lock=strict`
   entries get find-replaced, and even then only with the safety check that
   skips substrings of inflected forms. The primary enforcement layers are
   (in order): the system prompt, the per-chunk TM snapshot, and the audit
   suggestions. Find-replace is a last resort.

6. **Validation filter exception for micro-fixes**: the `not_too_similar`
   Levenshtein check must be **bypassed** for the following categories:
   `punctuation`, `grammar` (when the change is purely an accent/agreement),
   `markup`, plus all programmatic-origin findings (numbers, glossary
   mismatches). Only style-adjacent suggestions need the similarity check.
   Implementation note: add a boolean `is_micro_fix` to the suggestion
   schema, set by category at LLM-emit time, and have the validation layer
   skip `not_too_similar` when it's true.

## 7. Step-by-step plan

Each step is a self-contained PR. Don't combine steps into one branch.
Tests must pass before merging into `main` (or whatever the default
branch is — check `git branch -a`).

### 7.1. Step 1 — Glossary v2 schema + backward compatibility

**STATUS**: deliverables ready, may need application.

**Goal**: structured glossary (`category` + `lock`) with safe enforcement and
auto-upgrade for legacy data.

**Procedure**:

1. Check current state:
   ```bash
   ls glossary_v2.py 2>/dev/null && echo "module exists"
   grep -q "glossary_v2 as _gv2" translator.py && echo "import present"
   ```
2. If both exist, run the tests to verify nothing regressed:
   ```bash
   python test_glossary_v2.py
   python test_integration_step1.py
   ```
3. If anything is missing, apply the deliverables:
   - Copy `glossary_v2.py` to the project root (or wherever `translator.py`
     lives — same directory as `translator.py`).
   - Apply `translator_step1.patch` against the current `translator.py`:
     ```bash
     patch -p0 < translator_step1.patch
     ```
   - Run both test suites.
4. Update `STEP1_REPORT.md` with the result.

**Acceptance criteria**:

- [ ] `glossary_v2.py` is in the same dir as `translator.py`.
- [ ] `import glossary_v2 as _gv2` is in `translator.py`.
- [ ] `python test_glossary_v2.py` reports `✓ All tests passed.`
- [ ] `python test_integration_step1.py` reports `✓ All integration tests passed.`
- [ ] Existing translation sessions (in `translation_sessions/`) load without
      errors. The `[LOAD] Glossary upgraded to v2: N → M entries` log line
      should appear for old sessions but no exception should be raised.
- [ ] Starting a new translation produces glossary entries with `category`,
      `lock`, `id`, `frequency` fields populated. Verify by inspecting the
      `progress.json` of a freshly scanned session.

### 7.2. Step 2 — Profile-driven system prompts

**Goal**: replace the if/elif `style_instructions` block in
`make_system_prompt` with six independent profile blocks plus a blender for
mixed cases. Add `primary_profile` / `secondary_profile` to prescan output.

**Files affected**:

- `translator.py` — refactor `make_system_prompt` and `make_prescan_prompt`.
- New file `translation_profiles.py` — recommended (one constant per profile
  block keeps `translator.py` from bloating).

**Reference**: §2.2 of the architecture spec has the full text of all six
profile blocks (literary, academic, legal, theological, historical, plus
journalistic and technical as catch-all). Do not paraphrase those blocks —
use them verbatim. They were tuned by the owner and align with publishing
conventions he expects.

**Implementation notes**:

- Profile blocks are pure strings, not f-strings with parameters. They get
  concatenated into the system prompt by `make_system_prompt`.
- `make_system_prompt` signature must stay backward-compatible. Add a new
  optional parameter `profile: Optional[str] = None`. When `profile` is
  None, fall back to inferring from `style_register` (existing behavior).
- For mixed (when both `primary_profile` and `secondary_profile` are set),
  use the primary's hierarchy + DON'TS but include the secondary's
  ΑΠΑΡΑΒΑΤΟΙ ΚΑΝΟΝΕΣ. Deduplicate any overlapping rules.
- Update `prescan` (in `TranslationSession`) to read `primary_profile` and
  `secondary_profile` from the LLM response and store them on the session.
- The `style_register` field stays for backward compat. Sessions saved
  before Step 2 will have only `style_register`. On load, if no
  `primary_profile` is set, infer one from `style_register` using the same
  keywords the old if/elif used (`λογοτεχν` → literary, etc.).
- Add `primary_profile` and `secondary_profile` to `save_progress()` /
  `load_progress()`.

**Prescan prompt update**: §4.1 of the architecture spec shows the new
schema. Replace the `style_register` string field with the structured
profile fields. Keep `style_register` as a derived display string for the
UI (don't break the frontend).

**Acceptance criteria**:

- [ ] `translation_profiles.py` (or equivalent) exists with constants for
      `LITERARY`, `ACADEMIC`, `LEGAL`, `THEOLOGICAL`, `HISTORICAL`,
      `JOURNALISTIC`, `TECHNICAL`.
- [ ] Each constant matches the verbatim text from §2.2 of the spec.
- [ ] `make_system_prompt` accepts an optional `profile` argument and uses
      the new constants. Old callers (passing only `style_register`) still
      work.
- [ ] Prescan stores `primary_profile` and `secondary_profile` on the
      session.
- [ ] Loading a pre-Step-2 session works (legacy `style_register` only).
- [ ] Unit tests for profile selection: feed known `style_register` strings
      and verify the right profile is picked. Add at least 8 cases.
- [ ] Smoke test: translate a small literary chunk, then a small theological
      chunk. Eyeball the system prompts in logs to confirm the right block
      was injected.

### 7.3. Step 3 — Hard-passage radar

**Goal**: a pre-translation pass per chunk that flags idiomatic / ironic /
allusive / wordplay segments, so the translation prompt can warn the model
explicitly. Runs only in premium modes or when prescan flagged risk.

**Files affected**:

- `translator.py` — new function `radar_scan_chunk()`, integrated into the
  chunk loop.
- New module `radar.py` recommended for the radar prompt and scoring.

**Reference**: §2.3 (when to run), §4.3 (full radar prompt), §5.4 (output
schema), §6 of the spec for the cap (100-150 entries; this also applies to
the per-document risk register stored from Pass C of prescan).

**Implementation notes**:

- The radar runs **after prescan, before translation** for each chunk where
  it's needed.
- Trigger conditions:
  1. Translation mode is one of `premium-literary`, `premium-theological`,
     `premium-historical`.
  2. AND (the chunk overlaps with a paragraph_index_estimate from the
     pre-document risk register, OR a fast pattern match finds markers
     like quoted expressions, biblical-style capitals, "as if"/"like…"
     constructions, etc.).
- Output integrates into the translation user prompt as a `<HEADS_UP>`
  block (see §4.5 of the spec).
- Cache radar output per chunk. If translation has to retry the chunk,
  reuse the cached radar.
- Hard cap: keep at most ~10 hard passages per chunk in the heads-up block.
  If radar found more, sort by severity and keep the top 10.
- Risk register cap (document-level): when prescan Pass C produces more
  than 150 entries, score them by `frequency × estimated_difficulty` and
  keep top 150.

**Acceptance criteria**:

- [ ] `radar.py` exists with a `scan_chunk(chunk, source_language, model)`
      coroutine returning a list of `RadarFinding` dicts.
- [ ] Schema matches §5.4 of the spec (source_span, type, gloss,
      translation_hint, optional literal_translation_warning).
- [ ] Trigger logic correctly skips radar in default mode.
- [ ] Radar output is included in the translation user prompt only when
      non-empty.
- [ ] If radar fails (LLM error, JSON parse fail), translation still
      proceeds — radar is best-effort, never blocking.
- [ ] Risk register is capped at 150 with importance-based sorting.
- [ ] Unit test for the trigger logic (8+ cases: each premium mode × each
      condition combination).
- [ ] Smoke test: a literary chunk with a known idiom (e.g. "raining cats
      and dogs"). Verify radar flags it and the translation doesn't render
      it literally.

### 7.4. Step 4 — Tightened in-pipeline critique

**Goal**: narrow the existing critique pass to its real role: catching
hard, automatic-fixable errors. Push everything style-adjacent to the
post-translation audit (Step 7).

**Files affected**:

- `translator.py` — `make_critique_prompt` and the chunk_review aggregation.

**Reference**: §2.5 of the spec for the new prompt, §5.5 for the slimmed
schema.

**Implementation notes**:

- Replace `make_critique_prompt` with the version in §2.5 verbatim.
- The critique now emits **only** `severity ∈ {critical, major}`. The old
  `low` severity is gone. `medium` becomes `major`, `high` becomes `critical`.
- Categories shrink to: `omission`, `addition`, `factual`, `glossary`,
  `formatting`, `inversion`, `false_friend`. Old categories like `register`,
  `literalism` are removed at this layer (they move to audit).
- The chunk_review structure stays the same shape but `review_required`
  is computed against the new severity vocabulary.
- `apply_fixes` continues to work as-is; it just receives fewer issues now.
- Migration: old chunk_reviews in saved sessions use old categories. The
  load path should silently accept them; no auto-conversion needed because
  the fields are descriptive, not structural.

**Acceptance criteria**:

- [ ] New critique prompt is in place.
- [ ] Severity values restricted to `{critical, major}`.
- [ ] No suggestions of category `register` or `literalism` are emitted by
      the critique pass anymore.
- [ ] Apply-fixes still runs successfully on critique output.
- [ ] Old saved sessions load without crashing.
- [ ] Unit test: feed a chunk with a known omission AND a known stylistic
      preference; assert the omission is flagged but the stylistic one is
      not.

### 7.5. Step 5 — Programmatic audit checks (deterministic)

**Goal**: a deterministic, non-LLM audit pass that runs after translation
completes, producing concrete findings without false positives.

**Files affected**:

- New module `audit_programmatic.py`.
- `translator.py` — call `audit_programmatic.run()` from a new method
  `TranslationSession.run_audit_phase1()`.
- `main.py` — new endpoint `POST /api/translate/audit/{session_id}` that
  triggers Phase 1 (and later phases as they're built).

**Reference**: §3.1 of the spec for the check list, §5.8 for the
`ProgrammaticFinding` schema.

**Implementation notes**:

- All checks must run **without** any LLM call. Pure Python.
- Checks to implement:
  - `paragraph_count` — `len(source_paragraphs) == len(target_paragraphs)`.
  - `length_ratio` — per-paragraph char ratio outside [0.4, 3.0] for
    EN→EL, configurable per source language.
  - `empty_target` — non-empty source with empty target.
  - `markup_consistency` — `[B]/[I]/[U]` tag counts must match per paragraph.
  - `numbers_preservation` — extract digit groups and dates from source,
    verify presence in target. Handle Greek vs Latin digits both directions.
  - `proper_noun_preservation` — extract Capitalized non-stopwords from
    source, normalize, check via the glossary's translation memory.
  - `glossary_match` — per `lock=strict` entry, every source occurrence
    must have a matching target rendering in the same paragraph.
- Output: `List[ProgrammaticFinding]` per the schema.
- Findings can have `auto_fix_available=True` for cases like missing
  numbers (the source had "1872" and the target paragraph has no "1872",
  so we know what to insert — but DO NOT auto-fix in this step; just
  flag).
- Integrate into `progress.json` under `audit_phase1`.

**Acceptance criteria**:

- [ ] `audit_programmatic.py` exists with a single public function
      `run(session) -> dict`.
- [ ] All 7 checks listed in §3.1 of the spec are implemented.
- [ ] No LLM calls anywhere in this module.
- [ ] At least 15 unit tests covering each check in isolation.
- [ ] Integration test: feed a synthetic session with known issues
      (missing number, mismatched markup, glossary inconsistency) and
      verify exactly those issues are flagged and nothing else.
- [ ] New endpoint `/api/translate/audit/{session_id}` returns the
      findings.

### 7.6. Step 6 — Translation memory + consistency analysis

**Goal**: build a per-document translation memory after translation
completes; identify glossary terms (and detected proper nouns) with
inconsistent renderings.

**Files affected**:

- New module `translation_memory.py`.
- `audit_programmatic.py` — invoke TM build, surface inconsistencies as
  findings.
- `translator.py` — TM is also used **during** translation (see Step 3 /
  §2.4 of spec) for the per-chunk TM snapshot. If Step 3 was implemented
  with a placeholder TM, replace with the real one here.

**Reference**: §3.2 of the spec for the analysis logic, §5.7 for the
`TranslationMemoryEntry` schema.

**Implementation notes**:

- For each glossary entry and each detected proper noun (auto-extracted
  from source), record every paragraph + rendering.
- Greek inflection normalization: implement a lightweight Greek stemmer.
  Don't depend on external packages; the project doesn't have any. Either
  hand-roll a suffix-stripping function (good enough for proper nouns) or
  use `unicodedata.normalize('NFD')` + accent stripping + last-3-chars
  trimming as a heuristic. Mark the choice in code comments.
- Inconsistencies appear when normalized renderings differ. Don't flag
  inflectional variants — only stem mismatches.
- For proper nouns NOT in the glossary, use a frequency threshold ≥ 3 for
  inclusion (otherwise too noisy).

**Acceptance criteria**:

- [ ] `translation_memory.py` exists with a `build(session) ->
      List[TranslationMemoryEntry]` function.
- [ ] Greek stem normalization implemented and documented in comments.
- [ ] Consistency analysis flags real inconsistencies, ignores inflectional
      variants.
- [ ] TM is exposed via the audit endpoint.
- [ ] Unit tests for the stemmer (15+ cases including edge cases like
      καταλήξεις -ος/-ον/-η/-ς).
- [ ] Unit test for inconsistency detection: 'Λονδίνο' (8 paras) +
      'Λοντίνο' (1 para) → flagged. 'Λονδίνο' + 'Λονδίνου' → not flagged.

### 7.7. Step 7 — LLM strict audit + validation filter + Review UI

**Goal**: the heart of the post-translation experience. LLM-driven audit
with global context, server-side strict validation filter, and a new UI
that surfaces only validated suggestions.

**Files affected**:

- New module `audit_llm.py`.
- New module `audit_validation.py` (the strict filter).
- `translator.py` — orchestrate audit phases 4 & 5, store final
  `audit_suggestions` on session.
- `main.py` — new endpoints:
  - `GET /api/translate/audit/{session_id}` — fetch validated suggestions
    (replaces the placeholder from Step 5).
  - `POST /api/translate/audit/{session_id}/accept` — apply a single
    suggestion.
  - `POST /api/translate/audit/{session_id}/reject` — mark rejected.
  - `POST /api/translate/audit/{session_id}/edit` — accept with user
    modification.
  - `POST /api/translate/audit/{session_id}/bulk` — bulk apply by
    category/severity.
- `page.js` — new review section in the translation UI (under the
  existing review step).

**Reference**:

- §3.3 (boundary check), §3.4 (LLM strict audit prompt), §3.5 (validation
  filter rules), §3.6 (final suggestion schema), §3.7 (bulk actions and
  UI organization) of the spec.
- §4.5, §4.8, §4.9 for the relevant prompts (verbatim).
- §5.10 for the AuditSuggestion schema.

**Implementation notes** (in roughly the order to write things):

1. Implement boundary/completeness check (§3.3) as a function that runs N
   small LLM calls (one per boundary segment). Inputs: doc start, doc end,
   chunk boundaries.
2. Implement strict audit (§3.4) per chunk. The prompt is large; render it
   with the chunk + global context (document brief, glossary, TM snapshot
   for this chunk's terms, programmatic findings already detected for this
   chunk's paragraphs).
3. Implement the validation filter (§3.5) as `audit_validation.filter()`.
   This is the most important part of the whole audit phase. Most of the
   "no false positives" guarantee comes from this layer.
   - **Don't skip the micro-fix exception** (decision #6 in §6 of this
     brief). Categories `punctuation`, `markup`, plus all
     `phase_origin=programmatic` findings, plus `phase_origin=tm_consistency`
     findings, plus `phase_origin=boundary_check` findings — all skip the
     `not_too_similar` check. They have legitimate small-delta corrections.
4. Per-paragraph cap of 3 suggestions (sort by severity score, keep top
   3).
5. Final response includes the `validation_drop_stats` so we can verify
   the filter is doing real work (target: drop rate 50–80%).
6. UI: show suggestions grouped by paragraph, sorted by severity. Each
   suggestion has source_span and current_translation highlighted. Buttons:
   Accept, Edit, Reject. Bulk actions per §3.7 (and **only** the listed
   bulk actions — do NOT add "Apply all", "Apply all major", or "Apply all
   style"; those are explicitly forbidden in §3.7).

**Acceptance criteria**:

- [ ] All four audit phases (programmatic, TM, boundary, LLM) wired
      together into a single `run_audit()` orchestrator.
- [ ] Validation filter implemented per §3.5 verbatim.
- [ ] Generic-rationale blacklist regex applies per §3.5.
- [ ] Micro-fix exception correctly bypasses `not_too_similar` for the
      listed categories and phase origins.
- [ ] Per-paragraph cap of 3 enforced.
- [ ] All anchor verification rules pass before suggestions reach the UI.
- [ ] Endpoint returns `AuditSuggestion[]` per the schema.
- [ ] Bulk action endpoints only support the 4 actions listed in §3.7. The
      forbidden bulk actions return 400.
- [ ] UI groups by paragraph, sorts by severity, highlights spans.
- [ ] Unit tests for the validation filter with at least 20 cases (one per
      validation rule, plus the micro-fix exception cases).
- [ ] End-to-end smoke test: a 2-page document gets translated, audited,
      and 3+ suggestions surface for human review. Drop stats show > 50%
      filtered out.

## 8. Working agreement

### 8.1. Branching

One branch per step. Recommended naming:
```
v2/step-1-glossary-schema
v2/step-2-profile-prompts
v2/step-3-hard-passage-radar
v2/step-4-tightened-critique
v2/step-5-programmatic-audit
v2/step-6-translation-memory
v2/step-7-llm-audit-and-ui
```

After tests pass and acceptance criteria are met, open a PR titled
`Step N: <one-line description>` for review.

### 8.2. Reporting

After each step, write a `STEP_N_REPORT.md` with:

- What was changed (high-level, file by file)
- Tests added (count + scope)
- Test results
- Any deviation from the spec and why
- Open questions for the owner
- Any new feature flag added

These reports go in the project root and become part of the PR description.

### 8.3. Don'ts

- **Don't merge multiple steps** into one branch.
- **Don't add new dependencies** without flagging it in the report.
- **Don't change the `paraphraser.py` module** — separate concern.
- **Don't change the proofreader endpoints** under `/api/correction/...` or
  similar — those belong to the other module.
- **Don't add new bulk actions** beyond those in §3.7.
- **Don't paraphrase the prompts** in the spec. They were tuned. Use
  verbatim. If you think a prompt has a bug, raise it as an open question
  in the step report.

### 8.4. Testing approach by step

| Step | Test approach | LLM calls in tests? |
|------|---------------|---------------------|
| 1 | Unit + integration on synthetic data | No |
| 2 | Unit on profile selection + manual eyeball on real translations | Yes (smoke only) |
| 3 | Unit on trigger logic + manual eyeball on flagged passages | Yes (smoke only) |
| 4 | Unit on category/severity restrictions + manual eyeball | Yes (smoke only) |
| 5 | Unit per check + integration on synthetic session | No |
| 6 | Unit per stem function + integration | No |
| 7 | Unit per validation rule + e2e on a small real document | Yes (e2e) |

Smoke tests should use a small text sample (~500 words) to keep costs low.
Use `gemini-3-flash` for smokes when possible.

### 8.5. Rollback

Each step is reversible by reverting its branch. Keep migrations
(specifically the `load_progress` upgrade in Step 1) idempotent so
re-running them doesn't break anything.

## 9. Owner communication

The project owner is George (Greek-speaking, technical, very direct).

- Write step reports in **Greek**. He reads them in Greek.
- For inline code comments and PR descriptions, English is fine.
- When raising open questions, ask in Greek and be specific. He responds
  fast and likes concrete proposals over open-ended questions.
- He pays close attention to false positives in suggestion systems. If you
  spot a place where the audit might generate noise, flag it.

## 10. Quick reference: file map after all steps complete

```
proofreadai/
├── translator.py                    # main pipeline, refactored
├── glossary_v2.py                   # Step 1
├── translation_profiles.py          # Step 2
├── radar.py                         # Step 3
├── audit_programmatic.py            # Step 5
├── translation_memory.py            # Step 6
├── audit_llm.py                     # Step 7
├── audit_validation.py              # Step 7
├── main.py                          # endpoints throughout
├── page.js                          # UI updates in Step 7
├── tests/
│   ├── test_glossary_v2.py
│   ├── test_integration_step1.py
│   ├── test_profiles.py             # Step 2
│   ├── test_radar.py                # Step 3
│   ├── test_critique.py             # Step 4
│   ├── test_audit_programmatic.py   # Step 5
│   ├── test_translation_memory.py   # Step 6
│   ├── test_audit_validation.py     # Step 7
│   └── test_audit_e2e.py            # Step 7
├── proofreadai_translation_v2_architecture.md
├── STEP1_PATCH_SUMMARY.md
├── CLAUDE_CODE_BRIEF.md             # this file
└── STEP_<n>_REPORT.md               # one per completed step
```

---

## Kickoff prompt for Claude Code

When you start a new Claude Code session, paste this as the first message:

```
Διάβασε το CLAUDE_CODE_BRIEF.md, μετά το proofreadai_translation_v2_architecture.md.
Έλεγξε σε ποιο step βρίσκεται το repo (§5 του brief).
Πες μου τι θα κάνεις πριν αρχίσεις.
```

Don't start coding until the owner confirms.
